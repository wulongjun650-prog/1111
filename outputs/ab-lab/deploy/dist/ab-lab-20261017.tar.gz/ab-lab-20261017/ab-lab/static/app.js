import { createDashboard } from './dashboard.mjs';
import { applyTheme } from './theme.mjs';
import { themeFor, deviceBadge, icon, reputationView, countryBadge } from './presentation.mjs';
import { createReputationAutoCheck } from './reputation.mjs';
import { createCloudflareAutoCheck } from './cloudflare-status.mjs';
import { patchConfig, rulesConfig, parseLinks, previewURL, logPath, validateUpload, sitePath } from './helpers.mjs';
import { countryLabel } from './locale.mjs';
import { createSelection } from './selection.mjs';
import { isAdmin, isObserver, seesAll, chooseSite, accountSitePath } from './account-ui.mjs';
import { createSourceEditor } from './source-editor.mjs';
import { createBRedirects } from './b-redirects.mjs';
import { createDesk } from './desk.mjs';
import { createTracking } from './tracking.mjs';
import { createVisitWatch } from './visit-watch.mjs';

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const csrf = $('meta[name="csrf-token"]').content;
const target = $('meta[name="target-url"]').content;
let state = null;
let selectedSite = null;
let account = {role: document.body.dataset.accountRole};
let pendingActions = 0;
let siteLoading = true;
let catalog = null;
let dirty = false;
let editing = 0;
let configBusy = false;
let stateRequest = 0;
let logsRequest = 0;
let domainsRequest = 0;
let siteEventsRequest = 0;
let siteEventsSite = null;
let logPage = 1;
let logPages = 1;
let activeTab = 'overview';
const dashboard = createDashboard(api, () => seesAll(account) ? '所有域名' : '我的域名');
const sourceEditor = createSourceEditor({api, on, element, confirmAction, getSite:() => state?.site,
  onSaved:async result => {toast(`${result.version.slot} 源码已保存并发布，旧版本已保留。`); await refreshState();},
});
const tracking = createTracking({api, on, element, confirmAction, toast, getState:() => state, refresh: () => refreshState()});
const visitWatch = createVisitWatch({api, getSite: () => selectedSite, getDomain: () => currentDomain(), isLogsOpen: () => activeTab === 'logs', reloadLogs: () => loadLogs(logPage, {quiet: true})});
const bRedirects = createBRedirects({api, on, element, confirmAction, readOnly: isObserver(account), getSite:() => state?.site,
  onApplied:async result => {
    if (!result.changed) toast(result.check ? '这些位置已经是这条链接，没有新版本。' : '这个号码已经是当前号码。');
    else if (!result.check) toast(result.cloudflare?.ok ? 'WhatsApp 号码已更换并发布，Cloudflare 缓存已清除。' : result.cloudflare ? 'WhatsApp 号码已更换。Cloudflare 缓存没清掉，请稍后再试。' : 'WhatsApp 号码已更换并发布。进线语未改。', Boolean(result.cloudflare && !result.cloudflare.ok));
    else toast(result.check.status === 'unknown' ? 'B 页已换链并发布；此链接状态未知，请确认目标页面。' : 'B 页已换链并发布，旧版本已保留。');
    await refreshState();
  },
});
const desk = createDesk({api, on, element, readOnly: isObserver(account), livePhone: () => bRedirects.livePhone(), switchLive: (options) => bRedirects.switchLive(options), screenPath: () => accountSitePath('/api/desk/screen', selectedSite)});
const reputationChecking = new Set();
const cloudflareChecking = new Set();
const latestReputation = new Map();
const reputationAutoCheck = createReputationAutoCheck({
  check:async id=>(await api(`/api/sites/${id}/reputation/check`,{method:'POST',body:{}})).result,
  isActive:()=>activeTab === 'domains' && !document.hidden && Boolean(catalog?.google_reputation_configured),
  onUpdate:(id,update)=>{
    if (update.checking === true) reputationChecking.add(id);
    if (update.checking === false) reputationChecking.delete(id);
    if (update.result) {
      latestReputation.set(id,update.result);
      const site = catalog?.sites.find(item=>item.id === id);
      if (site) site.google_reputation = update.result;
    }
    const site = catalog?.sites.find(item=>item.id === id);
    const cell = $$('[data-reputation-site]').find(item=>item.dataset.reputationSite === id);
    if (site && cell) renderReputation(site,cell);
  },
});
const cloudflareAutoCheck = createCloudflareAutoCheck({
  check:async id=>(await api(`/api/sites/${id}/cloudflare/status`,{method:'POST',body:{}})),
  isActive:()=>!isObserver(account) && activeTab === 'domains' && !document.hidden && Boolean(catalog?.cloudflare_configured),
  onUpdate:(id,update)=>{
    if (update.checking === true) cloudflareChecking.add(id);
    if (update.checking === false) cloudflareChecking.delete(id);
    const site = catalog?.sites.find(item=>item.id === id);
    if (update.result?.site && site) {
      const becameActive = site.cf_status !== 'active' && update.result.site.cf_status === 'active';
      Object.assign(site, update.result.site);
      if (becameActive) toast(`${site.domain} 的 Cloudflare 已生效。`);
    }
    if (catalog) renderDomains();
  },
});
const rulesForm = $('#rules-form');
$$('[data-tab]').forEach(button => button.querySelector('span').replaceChildren(icon(button.dataset.tab === 'accounts' || button.dataset.tab === 'analysis' || button.dataset.tab === 'campaign' ? 'logs' : button.dataset.tab)));
const selections = Object.fromEntries(['countries','languages'].map(kind => [kind,createSelection(rulesForm.elements.namedItem(kind),kind)]));
const labels = {
  domains: ['域名管理', '域名管理', '统一查看谷歌风险、接入状态、备注与访问状态。'],
  overview: ['流量总览', '流量总览', '查看访问数据、国家分布与各站点表现。'],
  content: ['A/B 内容', 'A/B 内容', '先看现在用的那一版，再换链接或发布。'],
  desk: ['工单', '工单', '看在线人数和今天进线，并生成投手金额。'],
  rules: ['访问规则', '访问规则', '设置访问条件，保存后对当前站点生效。'],
  simulate: ['规则模拟', '规则模拟', '输入访问条件，检查已保存规则的判断结果。'],
  logs: ['访问日志', '访问日志', '查看文档请求、设备、国家与分流结果。'],
  analysis: ['数据深度分析', '数据深度分析', '只看当前管理站点的香港访客请求和落地页事件。'],
  campaign: ['投放数据', '投放数据', '按版位看进站、点击和拉起。标红只提醒，不会自动改页面。'],
  speed: ['网站测速', '网站测速', '看 PageSpeed 性能评分，并从香港或韩国实测网页打开速度。'],
  accounts: ['账号管理', '账号管理', '创建代理或观察号。观察号只看指定的一个域名。'],
};
const reasons = { blacklist: '命中黑名单', whitelist: '命中白名单', super_bot: '超级防爬虫', strict_bot: '严格防爬虫', bot_marker: '匹配机器人标记', ipv4: 'IPv4 限制', device: '设备限制', os_version: '系统版本限制', blocked_cidr: '命中屏蔽网段', country: '国家 / 地区限制', country_unknown: '国家未知', language: '语言限制', visit_limit: '超过访问次数', allowed: '规则通过', pass: '规则通过', force_a: '强制 A', force_b: '强制 B', protection_off: '防护已关闭' };
const formatDate = value => {
  const date = new Date(Number(value) * 1000);
  return Number.isNaN(date.valueOf()) ? '—' : date.toLocaleString('zh-CN', { hour12: false });
};
const campaignClock = value => {
  const date = new Date(Number(value) * 1000);
  if (!value || Number.isNaN(date.valueOf())) return '—';
  const parts = new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Hong_Kong', hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).formatToParts(date);
  const pick = type => parts.find(part => part.type === type)?.value || '';
  return `${pick('year')}-${pick('month')}-${pick('day')} ${pick('hour')}:${pick('minute')}:${pick('second')}`;
};
reasons.manual = '手动指定';
const traceLabels = { blacklist: '黑名单检查', whitelist: '白名单检查', super_bot: '超级防爬虫', strict_bot: '严格防爬虫', bot_marker: 'UA 特征检查', ipv4: 'IPv4 检查', device: '设备检查', os_version: '系统版本检查', blocked_cidr: '自定义网段检查', country: '国家检查', country_unknown: '国家检查', language: '语言检查', visit_limit: '访问次数检查' };
const number = value => Number(value ?? 0).toLocaleString('zh-CN');
const bytes = value => Number(value) < 1024 * 1024 ? `${(Number(value) / 1024).toFixed(1)} KiB` : `${(Number(value) / 1024 / 1024).toFixed(1)} MiB`;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = String(text);
  return node;
}

function toast(message, error = false) {
  const item = element('div', `toast${error ? ' error' : ''}`);
  item.setAttribute('role', error ? 'alert' : 'status');
  item.append(element('span', '', message));
  const close = element('button', '', '×');
  close.type = 'button';
  close.setAttribute('aria-label', '关闭通知');
  close.addEventListener('click', () => item.remove());
  item.append(close);
  $('#toast-region').append(item);
  if (!error) window.setTimeout(() => item.remove(), 6000);
}

function chooseKeptRecords(domain, watchers) {
  const names = watchers.map(item => item.domain).filter(Boolean).join('、');
  return new Promise(resolve => {
    const dialog = element('dialog', 'confirm-dialog');
    const title = element('h2', '', '彻底删除域名');
    title.id = 'confirm-title';
    dialog.setAttribute('aria-labelledby', title.id);
    const text = element('p', '', `彻底删除 ${domain}？页面、证书和宝塔站点都会删掉，域名列表和上方的站点选择也会一起消失。`);
    const note = element('p', '', `访问记录、请求记录、落地页事件和原始接收可以留在观察域名 ${names}。不保留的话，这些记录跟着删除。页面和号码不复制。观察域名上原来的记录不动。`);
    const actions = element('div', 'actions');
    const cancel = element('button', 'button secondary', '取消');
    const drop = element('button', 'button secondary', '不保留');
    const keep = element('button', 'button primary', '保留到观察域名');
    const finish = value => { dialog.close(); dialog.remove(); resolve(value); };
    cancel.type = drop.type = keep.type = 'button';
    cancel.addEventListener('click', () => finish(null));
    drop.addEventListener('click', () => finish(false));
    keep.addEventListener('click', () => finish(true));
    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(null); });
    actions.append(cancel, drop, keep);
    dialog.append(title, text, note, actions);
    document.body.append(dialog);
    dialog.showModal();
    cancel.focus();
  });
}

function confirmAction(message) {
  return new Promise(resolve => {
    const dialog = element('dialog', 'confirm-dialog');
    const title = element('h2', '', '确认操作');
    title.id = 'confirm-title'; dialog.setAttribute('aria-labelledby', title.id);
    const text = element('p', '', message);
    const actions = element('div', 'actions');
    const cancel = element('button', 'button secondary', '取消');
    const accept = element('button', 'button primary', '确认');
    const finish = value => { dialog.close(); dialog.remove(); resolve(value); };
    cancel.addEventListener('click', () => finish(false));
    accept.addEventListener('click', () => finish(true));
    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(false); });
    actions.append(cancel, accept); dialog.append(title, text, actions);
    document.body.append(dialog); dialog.showModal(); cancel.focus();
  });
}

// Every asynchronous UI event is handled through this boundary.
function on(node, event, handler) {
  node.addEventListener(event, async eventObject => {
    pendingActions++;
    updateSiteLock();
    try { await handler(eventObject); }
    catch (error) { if (!error.stale) toast(error.message || '操作失败，请稍后重试。', true); }
    finally { pendingActions--; updateSiteLock(); }
  });
}

function updateSiteLock() {
  $('#site-selector').disabled = !selectedSite || siteLoading || pendingActions > 0 || configBusy;
}

async function busy(button, action) {
  if (button?.disabled) return;
  if (button) { button.disabled = true; button.setAttribute('aria-busy', 'true'); }
  try { return await action(); }
  finally { if (button) { button.disabled = false; button.removeAttribute('aria-busy'); } }
}

async function api(path, { method = 'GET', body, raw = false, timeout } = {}) {
  const siteAtStart = selectedSite;
  const scopedPath = accountSitePath(path, siteAtStart);
  const siteScoped = scopedPath !== path || /^\/api\/sites\/(default|[a-f0-9]{32})\//.test(path);
  const headers = {};
  if (method !== 'GET') headers['X-CSRF-Token'] = csrf;
  if (body !== undefined) headers['Content-Type'] = raw ? 'application/octet-stream' : 'application/json';
  let response;
  try {
    response = await fetch(scopedPath, { method, headers, credentials: 'same-origin', cache: 'no-store', body: body === undefined ? undefined : raw ? body : JSON.stringify(body), signal: AbortSignal.timeout(timeout || (raw ? 120000 : 20000)) });
  } catch (error) {
    throw new Error(error.name === 'TimeoutError' ? '请求超时。操作可能已完成，请刷新状态确认后再试。' : '无法连接服务，请检查服务状态后重试。');
  }
  let data;
  try { data = await response.json(); } catch { throw new Error('服务返回了无法读取的数据，请刷新后重试。'); }
  if (siteScoped && selectedSite !== siteAtStart) {
    const error = new Error('站点已切换，忽略旧响应'); error.stale = true; throw error;
  }
  if (!response.ok) {
    if (response.status === 401) { window.location.assign('/login'); throw new Error('会话已过期，请重新登录。'); }
    const messages = { 400: '提交内容有误，请检查输入。', 403: '安全校验失败，请重新加载页面后重试。', 404: '内容已不存在，请刷新状态。', 409: '配置已被其他操作更新，已重新同步。你的规则草稿仍保留，请检查后再次保存。', 413: '文件过大，上传上限为 20 MiB。', 422: '输入未通过校验，请检查 IP、CIDR、网址或数值。', 429: '操作过于频繁，请稍后重试。' };
    const error = new Error(messages[response.status] || '服务暂时无法完成操作，请稍后重试。');
    error.status = response.status;
    if (response.status === 404 && siteScoped) {
      await loadDomains();
      if (selectedSite !== siteAtStart) error.stale = true;
    }
    if (typeof data.detail === 'string') error.detail = data.detail;
    if ([400, 422].includes(response.status) && typeof data.detail === 'string') error.message += ` ${data.detail}`;
    throw error;
  }
  return data;
}

if ($('#logout')) on($('#logout'), 'click', async () => {
  if (!await confirmAction('退出管理后台？未保存的修改不会保留。')) return;
  await api('/api/logout', { method: 'POST', body: {} });
  sessionStorage.removeItem('ab-observer-entered');
  window.location.replace('/login');
});

function setDirty(value) {
  dirty = value;
  $('#rules-dirty').textContent = value ? '有未保存的修改 · 刷新不会覆盖草稿' : '配置已同步';
  $('#rules-dirty').classList.toggle('dirty', value);
}

function fillRules() {
  for (const [name, value] of Object.entries(state.config.rules)) {
    const input = rulesForm.elements.namedItem(name);
    if (!input) continue;
    if (selections[name]) selections[name].set(value);
    else if (input.type === 'checkbox') input.checked = Boolean(value);
    else input.value = Array.isArray(value) ? value.join(input.tagName === 'TEXTAREA' ? '\n' : ', ') : value;
  }
  setDirty(false);
}

function syncDeliveryPanels() {
  const linkMode = state?.config?.content_mode === 'LINK';
  const linksCard = $('#links-card');
  const distributionField = $('#distribution-field');
  if (linksCard) linksCard.hidden = !linkMode;
  if (distributionField) distributionField.hidden = !linkMode;
}

function updateConfigControls() {
  syncDeliveryPanels();
  const locked = isObserver(account);
  $('#routing-controls').disabled = locked || !state || configBusy;
  $('#allowed-content-controls').disabled = locked || !state || configBusy;
  $('#content-controls').disabled = locked || !state || configBusy;
  $('#protection-toggle').disabled = locked || !state || configBusy;
  $('#hero-switch').disabled = locked || !state || configBusy;
  applyTheme(themeFor(state?.config));
  if (!state) {
    paintSecretWeapon(null);
    paintFollowStatus();
    return;
  }
  const angel = themeFor(state.config) === 'angel';
  const forced = state.config.routing !== 'RULES';
  $('#hero-title').textContent = `放行配置 · 内容 ${angel ? 'A' : 'B'}`;
  $('#hero-description').textContent = !state.site.enabled ? '此域名已下线，配置保留，上线后恢复访问。' : forced ? '全局强制模式：所有访问固定展示此内容。' : !state.config.protection ? '规则防护已关闭：所有访客展示此内容。' : '通过规则的访问，将展示此内容。';
  $('#hero-mode').textContent = !state.site.enabled ? '域名已下线' : forced ? `全局强制 · 全部展示 ${state.config.routing.slice(-1)}` : `规则模式 · 放行后展示 ${state.config.allowed_slot}`;
  $('#sidebar-theme').textContent = `当前展示内容 ${angel ? 'A' : 'B'}`;
  $$('[data-routing]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.routing === state.config.routing)));
  const slot = state.config.allowed_slot;
  const active = state.config.routing === 'RULES';
  $$('[data-allowed-slot]').forEach(button => {
    const selected = button.dataset.allowedSlot === (button.closest('#hero-switch') ? (angel ? 'A' : 'B') : slot);
    button.setAttribute('aria-pressed', String(selected));
    button.classList.toggle('primary', selected);
    button.classList.toggle('secondary', !selected);
    const caption = button.querySelector('[data-slot-caption]');
    if (caption) caption.textContent = selected ? active ? '当前启用' : '强制展示' : '切换内容';
  });
  $('#allowed-slot-badge').textContent = `已选择 ${slot}${active ? '' : ' · 暂未生效'}`;
  $('#overview-allowed-status').textContent = `放行后展示 ${slot}${active ? '' : '（全局强制模式下暂不生效）'}`;
  const status = $('#allowed-content-status');
  status.className = active && state.config.protection ? 'subtle' : 'notice warning';
  status.textContent = !active ? `当前为全局强制 ${state.config.routing.slice(-1)}，已跳过规则。点击上方按钮可恢复按规则分流。`
    : !state.config.protection ? `注意：规则防护已关闭，所有访客都将展示 ${slot}。如需过滤，请到“概览”开启规则防护。`
    : `当前生效：拦截 → A；放行 → ${slot}。已保存的规则保持不变。`;
  const ready = state.config.content_mode === 'PAGE' ? Boolean(state.slots[slot]) : state.links.some(link => link.slot === slot);
  if (!ready) status.textContent += ` 注意：${slot} 尚未${state.config.content_mode === 'PAGE' ? '发布页面' : '配置链接'}，放行访问将返回维护提示。`;
  $('#protection-toggle').setAttribute('aria-checked', String(state.config.protection));
  $('#content-mode').value = state.config.content_mode;
  $('#distribution').value = state.config.distribution;
  $('#distribution').disabled = state.config.content_mode !== 'LINK';
  paintSecretWeapon(state.direct_mode || null);
  paintFollowStatus();
}

function paintFollowStatus() {
  const status = $('#follow-status');
  if (!status) return;
  if (!catalog) {
    status.textContent = '正在读取观察域名。';
    return;
  }
  const sites = catalog.sites || [];
  const current = sites.find(item => item.id === selectedSite);
  const watchers = sites.filter(item => item.observer_account);
  if (!watchers.length) {
    status.textContent = '还没有观察域名。请先在域名列表把一个域名设为观察域名。';
    return;
  }
  const names = watchers.map(item => item.domain || '观察域名').join('、');
  if (current?.mirror_source) {
    status.textContent = `当前选中的是观察域名，正在跟着 ${current.mirror_domain || '投放域名'}。请改选要跟着的投放域名，再点设置更寻。`;
    return;
  }
  const currentName = current?.domain || '当前域名';
  if (watchers.every(item => item.mirror_source === selectedSite)) {
    status.textContent = `观察域名 ${names} 正在跟着 ${currentName}。再点一次会把页面和号码同步成问卷版，已有记录不删。`;
    return;
  }
  const now = watchers.map(item => `${item.domain || '观察域名'}跟着${item.mirror_domain || '尚未指定'}`).join('，');
  status.textContent = `${now}。点设置更寻后改成跟着 ${currentName}，两边已有的访问记录都保留。`;
}

function paintSecretWeapon(mode) {
  const button = $('#secret-weapon');
  button.classList.remove('weapon-abc', 'weapon-abcabc', 'weapon-cba');
  if (mode === 'ABC') {
    button.textContent = 'ABC';
    button.classList.add('weapon-abc');
    button.title = 'ABC：弹窗已取消，领取直接跳 WhatsApp。再点一次填上 ABCABC。';
    button.setAttribute('aria-label', 'ABC，弹窗已取消');
  } else if (mode === 'ABCABC') {
    button.textContent = 'ABCABC';
    button.classList.add('weapon-abcabc');
    button.title = 'ABCABC：开关已填成 ABCABC。再点一次换回选择框。';
    button.setAttribute('aria-label', 'ABCABC');
  } else if (mode === 'CBA') {
    button.textContent = '*';
    button.classList.add('weapon-cba');
    button.title = 'CBA：选择框已换回。再点一次取消弹窗。';
    button.setAttribute('aria-label', 'CBA，选择框已换回');
  } else {
    button.textContent = '秘密武器';
    button.title = '去掉领取前的弹窗';
    button.setAttribute('aria-label', '秘密武器');
  }
}

let pageTitles = null;
let pageTitleRequest = 0;
let pageTitleSite = null;

async function loadPageTitles() {
  const request = ++pageTitleRequest;
  const site = selectedSite;
  if (pageTitleSite !== site) {
    pageTitles = null;
    pageTitleSite = null;
    paintPageTitles();
  }
  const result = await api('/api/page-title');
  if (request !== pageTitleRequest || site !== selectedSite) return;
  pageTitleSite = site;
  pageTitles = result.titles || null;
  paintPageTitles();
}

function paintPageTitles() {
  const root = $('#page-title-fields');
  if (!root) return;
  const locked = isObserver(account) || Boolean(state?.site?.mirror_source);
  for (const slot of ['A', 'B']) {
    let row = root.querySelector(`[data-title-slot="${slot}"]`);
    const info = pageTitleSite === selectedSite ? (pageTitles?.[slot] || {version_id:'', title:''}) : {version_id:'', title:''};
    if (!row) {
      row = element('form', 'page-title-row');
      row.dataset.titleSlot = slot;
      const label = element('label', '', `${slot} 网站标题`);
      const input = element('input');
      input.name = 'title';
      input.maxLength = 120;
      input.placeholder = '例如 講經MAN｜10月14日港股名單';
      input.autocomplete = 'off';
      input.spellcheck = false;
      label.append(input);
      const button = element('button', 'button secondary small', '保存标题');
      button.type = 'submit';
      const note = element('small', 'page-title-note', '');
      row.append(label, button, note);
      on(row, 'submit', async event => {
        event.preventDefault();
        const current = row.dataset.version;
        if (!current) return;
        const result = await api('/api/page-title', {method:'POST', body:{slot, title:input.value.trim(), expected_published:current}});
        const cache = result.cloudflare;
        const extra = cache ? (cache.ok ? 'Cloudflare 缓存已清掉。' : 'Cloudflare 缓存没清掉，请稍后再试。') : '';
        toast(`${slot} 网站标题已改成「${result.title}」。${extra}`, Boolean(cache && !cache.ok));
        await refreshState();
      });
      root.append(row);
    }
    const input = row.querySelector('input');
    const published = Boolean(info.version_id);
    if (document.activeElement !== input) input.value = info.title || '';
    input.disabled = locked || !published;
    row.querySelector('button').disabled = locked || !published;
    row.dataset.version = info.version_id || '';
    row.querySelector('small').textContent = locked && state?.site?.mirror_source
      ? '观察域名跟着投放域名，请到投放域名上改标题。'
      : published ? '只改这一页的标题，其他内容不动。' : '还没有发布页面。';
  }
}

function renderState() {
  $$('.tab-panel').forEach(panel => { panel.inert = false; });
  $('#open-target').href = state.target_url;
  $('#open-target').hidden = false;
  $('#site-context').textContent = `仅修改 ${state.site.domain || '当前站点'} 的配置 · 图表范围可独立选择`;
  if (activeTab === 'overview') dashboard.refresh();
  const geo = state.health.geoip_detail;
  $('#geoip-status').textContent = state.health.geoip ? `已就绪 · ${geo?.built_at ? new Date(geo.built_at * 1000).toLocaleDateString('zh-CN') : '本地数据库'}` : '国家库不可用 · 请检查安装';
  $('#geoip-warning').hidden = Boolean(state.health.geoip);
  $('#current-mode').textContent = state.config.content_mode === 'PAGE' ? '页面内容' : '链接跳转';
  $('#published-count').textContent = `${Object.values(state.slots).filter(Boolean).length} / 2 个内容位`;
  $('#last-sync').textContent = `最近同步 ${new Date().toLocaleTimeString('zh-CN', { hour12: false })}`;
  $('#connection').textContent = '服务已连接';
  $('#connection').className = 'badge green';
  $('#load-error').hidden = true;
  for (const id of ['rules-fields', 'links-fields', 'simulate-fields', 'reset-counters']) $(`#${id}`).disabled = isObserver(account);
  updateConfigControls();
  if (!dirty) fillRules();
  renderSlots();
  bRedirects.update(state);
  renderLinks();
  if (activeTab === 'content') {
    tracking.load().catch(error => { if (!error.stale) toast(error.message || '统计代码读取失败。', true); });
    loadPageTitles().catch(error => { if (!error.stale) toast(error.message || '网站标题读取失败。', true); });
  }
}

async function refreshState() {
  if (!selectedSite) return;
  const request = ++stateRequest;
  try {
    const result = await api('/api/state');
    if (request !== stateRequest) return;
    state = result;
    renderState();
  } catch (error) {
    if (request === stateRequest) {
      $('#connection').textContent = '连接异常';
      $('#connection').className = 'badge red';
      $('#load-error').hidden = false;
    }
    throw error;
  }
}

async function saveConfig(config, ruleSave = false) {
  if (!state || configBusy) return;
  configBusy = true;
  const editAtStart = editing;
  ++stateRequest; // Ignore reads that started before this write.
  updateConfigControls();
  try {
    const updated = await api('/api/config', { method: 'PUT', body: { config, revision: state.revision } });
    ++stateRequest;
    state = updated;
    if (ruleSave && editing === editAtStart) setDirty(false);
    renderState();
    const cache = updated.cloudflare;
    const cleared = cache?.ok ? ' Cloudflare 缓存已清除，请刷新落地页。' : '';
    const failed = cache && cache.ok === false ? ' Cloudflare 缓存没清掉，请再保存一次。' : '';
    toast((ruleSave ? '访问规则已保存。' : '配置已更新，即刻生效。') + cleared + failed);
  } catch (error) {
    if (error.status === 409) {
      try { await refreshState(); } catch { toast('重新同步失败，草稿仍保留。请刷新状态后重试。', true); }
    }
    throw error;
  } finally { configBusy = false; updateConfigControls(); updateSiteLock(); }
}

function humanSwitch(site, label, checked, action) {
  const row = element('label', 'domain-challenge-row');
  row.append(document.createTextNode(label));
  const toggle = element('button', 'switch');
  toggle.type = 'button';
  toggle.setAttribute('role', 'switch');
  toggle.setAttribute('aria-checked', checked ? 'true' : 'false');
  toggle.setAttribute('aria-label', `${site.domain || '这个域名'} ${label}`);
  toggle.append(element('span'));
  on(toggle, 'click', action);
  row.append(toggle);
  return row;
}

function actionButton(text, action, className = 'button secondary small') {
  const button = element('button', className, text);
  button.type = 'button';
  on(button, 'click', () => busy(button, action));
  return button;
}

function renderSlots() {
  const root = $('#slot-cards');
  // Keep native file inputs intact on refresh, including any selected file.
  for (const slot of ['A', 'B']) {
    let card = $(`#slot-${slot}`);
    if (!card) {
      card = element('article', 'card'); card.id = `slot-${slot}`;
      const heading = element('div', 'slot-heading');
      heading.append(element('span', `slot-letter slot-${slot.toLowerCase()}`, slot));
      const title = element('div'); title.append(element('h2', '', `${slot} 内容`), element('small', '', slot === 'A' ? '拦截时看到的页面' : '放行后选 B 时看到的页面')); heading.append(title);
      const live = element('div', 'slot-live'); live.id = `slot-live-${slot}`;
      const form = element('form', 'upload-form');
      const label = element('label', '', '导入新版本');
      const input = element('input'); input.type = 'file'; input.accept = '.zip,.html,.htm'; input.required = true; input.name = 'file'; input.disabled = !state;
      label.append(input);
      const submit = element('button', 'button secondary small', '上传并创建版本'); submit.type = 'submit'; submit.disabled = !state;
      form.append(label, element('small', '', slot === 'B'
        ? 'ZIP 或 HTML，最大 20 MB。拖进来会自动补上报代码，谷歌代码不动。上传后要点下面的「用这一版」才会生效。'
        : 'ZIP 或 HTML，最大 20 MB。上传后要点下面的「用这一版」才会生效。'), submit);
      on(form, 'submit', async event => {
        event.preventDefault();
        await busy(submit, async () => {
          const file = input.files[0]; validateUpload(file);
          input.disabled = true;
          try {
            const uploaded = await api(`/api/upload/${slot}?name=${encodeURIComponent(file.name)}`, { method: 'POST', raw: true, body: file });
            input.value = '';
            const implant = uploaded.implant && uploaded.implant.label ? ` ${uploaded.implant.label}。` : '';
            toast(`${slot} 版本已导入，尚未发布。${implant}`);
            await refreshState();
            if (slot === 'B') await bRedirects.selectVersion(uploaded.version.id);
          } finally { input.disabled = false; }
        });
      });
      const versions = element('div', 'version-list'); versions.id = `versions-${slot}`;
      card.append(heading, live, form, versions); root.append(card);
    }
    if (state) card.querySelectorAll('.upload-form input, .upload-form button').forEach(control => { if (!control.hasAttribute('aria-busy')) control.disabled = isObserver(account); });
    const current = state?.versions.find(version => version.id === state.slots[slot]);
    const live = $(`#slot-live-${slot}`);
    live.replaceChildren(element('span', 'badge green', '当前发布'));
    if (current) {
      live.append(element('strong', '', formatDate(current.created)));
      live.append(element('small', '', `${current.name} · ${number(current.files)} 个文件`));
      live.append(actionButton('编辑源码', () => sourceEditor.open(current), 'button secondary small slot-source-edit'));
    } else live.append(element('strong', '', state?.slots[slot] ? '已发布版本' : '尚未发布'));
    const versions = $(`#versions-${slot}`); versions.replaceChildren();
    const items = state?.versions.filter(version => version.slot === slot) || [];
    const extras = items.filter(version => version.id !== state?.slots[slot]);
    if (extras.length) {
      const cleanup = element('div', 'version-cleanup');
      cleanup.append(element('small', '', state.slots[slot] ? `还有 ${extras.length} 个未发布版本` : `还没发布。这 ${extras.length} 个版本都可以清掉`));
      cleanup.append(actionButton('清理未发布版本', async () => {
        const message = state.slots[slot]
          ? `彻底删除 ${extras.length} 个未发布的 ${slot} 版本？只保留当前发布版本。源码和记录都会删除，无法恢复。`
          : `当前没有发布中的 ${slot} 版本。彻底删除全部 ${extras.length} 个 ${slot} 版本？源码和记录都会删除，无法恢复。`;
        if (!await confirmAction(message)) return;
        const result = await api(`/api/versions/${slot}/cleanup`, { method: 'POST', body: {} });
        toast(`已删除 ${result.deleted} 个未发布 ${slot} 版本。`);
        await refreshState();
      }, 'button quiet small'));
      versions.append(cleanup);
    }
    if (!items.length) versions.append(element('p', 'empty-state', state ? '还没有版本。先导入一个页面。' : '连接服务后，版本会显示在这里。'));
    const publishedId = state?.slots[slot];
    const sorted = [...items].sort((a, b) => Number(b.created) - Number(a.created) || String(b.id).localeCompare(String(a.id)));
    const published = sorted.find(version => version.id === publishedId) || null;
    const newestOther = sorted.find(version => version !== published) || null;
    const visible = [published, newestOther].filter(Boolean);
    const visibleIds = new Set(visible.map(version => version.id));
    const older = sorted.filter(version => !visibleIds.has(version.id));
    const appendVersion = (version, parent) => {
      const isPublished = version.id === publishedId;
      const row = element('div', 'version-row');
      row.append(element('div', 'version-name', formatDate(version.created)));
      row.append(element('p', 'version-meta', `${version.name} · ${number(version.files)} 个文件 · ${bytes(version.bytes)}`));
      const actions = element('div', 'actions');
      actions.append(actionButton('预览', () => preview(version)));
      actions.append(actionButton('编辑源码', () => sourceEditor.open(version)));
      if (!isPublished) actions.append(actionButton('删除', async () => {
        if (!await confirmAction(`彻底删除「${version.name}」？源码和记录都会删除，无法恢复。当前发布版本不受影响。`)) return;
        await api(`/api/versions/${slot}/${version.id}`, { method: 'DELETE' });
        toast(`${slot} 版本已删除。`);
        await refreshState();
      }, 'button quiet small'));
      if (isPublished) actions.append(element('span', 'badge green', '当前发布'));
      else actions.append(actionButton('用这一版', async () => {
        if (!await confirmAction(`改用 ${formatDate(version.created)} 的「${version.name}」作为 ${slot}？当前这一版会留下来，随时可以换回去。`)) return;
        await api(`/api/publish/${slot}`, { method: 'POST', body: { version_id: version.id } });
        toast(`${slot} 已换成这一版。`); await refreshState();
      }, 'button primary small'));
      const codes = element('div', 'version-codes');
      codes.hidden = true;
      codes.dataset.trackingSlot = slot;
      codes.dataset.trackingVersion = version.id;
      codes.append(element('span', 'version-codes-text', ''));
      const full = element('button', 'button secondary small version-full', '完整代码');
      full.type = 'button';
      full.hidden = true;
      on(full, 'click', () => tracking.showFull(slot, version.id));
      codes.append(full);
      const hash = element('details', 'version-hash'); hash.append(element('summary', '', '版本校验值'), element('span', '', version.sha256));
      row.append(actions, codes, hash); parent.append(row);
    };
    for (const version of visible) appendVersion(version, versions);
    if (older.length) {
      const details = element('details', 'version-older');
      details.open = versions.dataset.olderOpen === 'true';
      details.append(element('summary', '', `更早的 ${older.length} 个版本`));
      details.addEventListener('toggle', () => { versions.dataset.olderOpen = String(details.open); });
      for (const version of older) appendVersion(version, details);
      versions.append(details);
    }
  }
}

let previewRequest = 0;
async function preview(version) {
  const request = ++previewRequest;
  const result = await api('/api/preview', { method: 'POST', body: { version_id: version.id } });
  if (request !== previewRequest) return;
  const url = previewURL(result.url, target);
  const frame = element('iframe');
  frame.title = `${version.slot} 内容预览：${version.name}`;
  frame.setAttribute('sandbox', 'allow-scripts allow-forms');
  frame.referrerPolicy = 'no-referrer'; frame.loading = 'lazy'; frame.src = url;
  $('#preview-frame').replaceChildren(frame);
  $('#preview-title').textContent = `${version.slot} · ${version.name}`;
  $('#preview-panel').hidden = false;
  $('#preview-panel').scrollIntoView({ block: 'start', behavior: 'smooth' });
}

function closePreview() {
  ++previewRequest;
  $('#preview-frame').replaceChildren(); $('#preview-panel').hidden = true;
}

function renderLinks() {
  $('#link-count').textContent = `${number(state.links.length)} 个链接`;
  const root = $('#links-list'); root.replaceChildren();
  if (!state.links.length) root.append(element('p', 'empty-state', '还没有链接。每行一个，添加后就会开始分配。'));
  for (const link of state.links) {
    const row = element('div', 'link-row');
    row.append(element('span', `badge ${link.slot === 'A' ? 'amber' : 'indigo'}`, link.slot), element('span', 'link-url', link.url), element('span', 'link-hits', `${number(link.hits)} 次访问`));
    row.append(actionButton('删除', async () => {
      if (!await confirmAction(`删除此 ${link.slot} 链接？\n${link.url}`)) return;
      await api(`/api/links/${encodeURIComponent(link.id)}`, { method: 'DELETE' });
      toast('链接已删除。'); await refreshState();
    }, 'text-button danger'));
    root.append(row);
  }
}

async function loadAudit() {
  if (!selectedSite || !state) return;
  const request = stateRequest;
  const data = await api('/api/audit');
  if (request !== stateRequest) return;
  const root = $('#audit-list'); root.replaceChildren();
  if (!data.items.length) root.append(element('p', 'empty-state', '暂无操作记录。配置、上传与发布后可在这里查看。'));
  for (const item of data.items) {
    const row = element('div', 'audit-item');
    row.append(element('strong', '', item.action), element('small', '', `${formatDate(item.created)} · ${typeof item.detail === 'string' ? item.detail : JSON.stringify(item.detail)}`)); root.append(row);
  }
}

function logParams() {
  const form = $('#log-filters');
  return new URLSearchParams({ days: form.elements.days.value, slot: form.elements.slot.value });
}

function visitAddress(ip) {
  const text = String(ip || '');
  if (!text || text.includes('/')) return '—';
  return text;
}

function visitDeviceLine(details) {
  if (!details) return 'iOS 18 以上 · Safari';
  let os = details.os || '';
  let browser = details.browser || '';
  if (!os || os === '系统未知') os = 'iOS 18 以上';
  if (!browser || browser === '浏览器未知') browser = os.startsWith('iOS') || os.startsWith('macOS') ? 'Safari' : '内置浏览器';
  const osMajor = Number((os.match(/iOS\s+(\d+)/) || [])[1]);
  const safariMajor = Number((browser.match(/Safari\s+(\d+)/) || [])[1]);
  if (os.startsWith('iOS') && safariMajor > osMajor) os = `iOS ${safariMajor} 以上`;
  return `${os} · ${browser}`;
}

async function loadLogs(page = 1, {quiet = false} = {}) {
  if (!selectedSite || !state) return;
  const request = ++logsRequest;
  const domain = currentDomain() || '当前域名';
  $('#logs-scope').textContent = `只显示 ${domain}，其他域名不在这里`;
  const params = logParams();
  $('#export-logs').href = sitePath(`/api/logs.csv?${params}`, selectedSite);
  params.set('page', String(page));
  if (!quiet) {
    $('#logs-summary').textContent = `正在加载 ${domain} 的访问记录…`;
    $('#logs-prev').disabled = true; $('#logs-next').disabled = true;
  }
  try {
    const data = await api(`/api/logs?${params}`);
    if (request !== logsRequest) return;
    logPage = data.page; logPages = Math.max(1, data.pages);
    const root = $('#logs-body'); root.replaceChildren();
    if (!data.items.length) {
      const row = element('tr'); const cell = element('td', 'empty-state', `${domain} 还没有访问记录。`); cell.colSpan = 8; row.append(cell); root.append(row);
    }
    for (const item of data.items) {
      const row = element('tr');
      row.append(element('td', '', formatDate(item.created)));
      const country = element('td', 'country-name'); country.append(countryBadge(item.country)); row.append(country);
      row.append(element('td', 'ip-cell', visitAddress(item.ip)));
      const device = element('td', 'device-cell'); device.append(deviceBadge(item));
      device.append(element('small', '', visitDeviceLine(item.device_details)));
      device.title = '来自浏览器 User-Agent 声明，可能被精简或伪造；不能保证真实型号'; row.append(device);
      const slot = element('td'); slot.append(element('span', `badge ${item.slot === 'A' ? 'amber' : 'indigo'}`, item.slot)); row.append(slot);
      row.append(element('td', '', reasons[item.reason] || item.reason));
      const path = element('td', 'path-cell', logPath(item.path)); path.title = logPath(item.path); row.append(path);
      row.append(element('td', '', { PAGE: '页面', LINK: '链接', RULES: '规则', FORCE_A: '强制 A', FORCE_B: '强制 B' }[item.mode] || item.mode)); root.append(row);
    }
    $('#logs-summary').textContent = `${domain} · 共 ${number(data.total)} 条 · 每页 25 条`;
    $('#logs-page').textContent = `${logPage} / ${logPages}`;
  } catch (error) {
    if (request === logsRequest) $('#logs-summary').textContent = '加载失败；请点击「查询」重试。';
    throw error;
  } finally {
    if (request === logsRequest) { $('#logs-prev').disabled = logPage <= 1; $('#logs-next').disabled = logPage >= logPages; }
  }
}

const siteFreeTabs = ['domains', 'accounts', 'analysis', 'campaign', 'speed'];
const alwaysOpenPanels = ['panel-domains', 'panel-accounts', 'panel-analysis', 'panel-campaign', 'panel-speed'];
let analysisRequest = 0;

function clipCell(text, className = 'path-cell') {
  const value = text || '';
  const cell = element('td', className, value || '—');
  cell.title = value;
  return cell;
}

async function loadAnalysis() {
  const request = ++analysisRequest;
  const domain = currentDomain();
  const days = $('#analysis-days').value || '7';
  if (!domain) {
    $('#analysis-summary').textContent = '请先在左上角选择域名。';
    $('#analysis-events-summary').textContent = '请先在左上角选择域名。';
    $('#analysis-download').removeAttribute('href');
    const requests = $('#analysis-requests');
    requests.replaceChildren();
    const row = element('tr');
    const cell = element('td', 'empty-state', '请先在左上角选择域名。');
    cell.colSpan = 9;
    row.append(cell);
    requests.append(row);
    const events = $('#analysis-events');
    events.replaceChildren();
    const eventRow = element('tr');
    const eventCell = element('td', 'empty-state', '请先在左上角选择域名。');
    eventCell.colSpan = 3;
    eventRow.append(eventCell);
    events.append(eventRow);
    return;
  }
  const params = new URLSearchParams({ days, domain });
  $('#analysis-download').href = `/api/analysis/report?${params}`;
  try {
    const data = await api(`/api/analysis?${params}`);
    if (request !== analysisRequest) return;
    $('#analysis-summary').textContent = `${domain} · 香港请求 ${number(data.requests.total)} 条，下面显示最近 ${number(data.requests.items.length)} 条`;
    $('#analysis-events-summary').textContent = `${domain} · 落地页事件 ${number(data.events.total)} 条，下面显示最近 ${number(data.events.items.length)} 条`;
    const requests = $('#analysis-requests');
    requests.replaceChildren();
    if (!data.requests.items.length) {
      const row = element('tr');
      const cell = element('td', 'empty-state', `这段时间，${domain} 没有香港访客请求。`);
      cell.colSpan = 9;
      row.append(cell);
      requests.append(row);
    } else for (const item of data.requests.items) {
      const row = element('tr');
      row.append(
        element('td', 'visit-time', formatDate(item.created)),
        element('td', '', item.domain),
        element('td', '', item.status),
        element('td', '', item.wa_number || '—'),
        element('td', '', item.cf_cache_status || '—'),
        element('td', '', item.ch_platform_version || '—'),
        clipCell(item.referer),
        clipCell(item.query),
        clipCell(item.ua),
      );
      requests.append(row);
    }
    const events = $('#analysis-events');
    events.replaceChildren();
    if (!data.events.items.length) {
      const row = element('tr');
      const cell = element('td', 'empty-state', `这段时间，${domain} 没有落地页事件。`);
      cell.colSpan = 3;
      row.append(cell);
      events.append(row);
    } else for (const item of data.events.items) {
      const row = element('tr');
      row.append(element('td', 'visit-time', formatDate(item.created)), element('td', '', item.domain), clipCell(item.body, 'analysis-wide'));
      events.append(row);
    }
  } catch (error) {
    if (request === analysisRequest) $('#analysis-summary').textContent = '加载失败，请再查询一次。';
    throw error;
  }
}

let campaignRequest = 0;
let campaignTimer = 0;

function campaignQuery() {
  const params = new URLSearchParams();
  params.set('range', $('#campaign-range').value || 'today');
  if ($('#campaign-range').value === 'custom') {
    params.set('start', $('#campaign-start').value);
    params.set('end', $('#campaign-end').value);
  }
  const domain = currentDomain();
  const box = $('#campaign-domain');
  if (box) box.value = domain;
  if (domain) params.set('domain', domain);
  for (const [name, id] of [['dest_app', 'campaign-dest'], ['placement', 'campaign-placement'], ['youtube', 'campaign-youtube'], ['opener', 'campaign-opener'], ['device', 'campaign-device'], ['wa_env', 'campaign-env'], ['link_type', 'campaign-link'], ['model', 'campaign-model']]) {
    const value = $(`#${id}`).value.trim();
    if (value) params.set(name, value);
  }
  return params;
}

function percent(value) {
  return value == null ? '—' : `${(Number(value) * 100).toFixed(1)}%`;
}

function watchCampaign(active) {
  clearInterval(campaignTimer);
  campaignTimer = 0;
  if (active) campaignTimer = setInterval(() => { if (activeTab === 'campaign') loadCampaign(); }, 60000);
}

function funnelCells(item) {
  return [
    element('td', '', number(item.page_view)),
    element('td', '', number(item.gate_open)),
    element('td', '', number(item.gate_step2)),
    element('td', '', number(item.gate_close)),
  ];
}

function alertCell(item) {
  return element('td', '', item.alert ? (item.alert_reason || '是') : '—');
}

function renderCampaignSystems(systems) {
  const body = $('#campaign-systems');
  if (!body) return;
  body.replaceChildren();
  if (!systems.length) {
    const row = element('tr');
    const cell = element('td', 'empty-state', '这段时间没有进站或点击。');
    cell.colSpan = 10;
    row.append(cell);
    body.append(row);
    return;
  }
  for (const item of systems) {
    const row = element('tr', item.alert ? 'campaign-alert' : '');
    if (item.alert) row.title = item.alert_reason;
    row.append(
      element('td', '', item.system),
      element('td', '', number(item.visits)),
      ...funnelCells(item),
      element('td', '', number(item.clicks)),
      element('td', '', number(item.click_times)),
      element('td', '', number(item.opens)),
      alertCell(item),
    );
    body.append(row);
  }
}

function renderCampaignPlacements(placements) {
  const body = $('#campaign-placements');
  if (!body) return;
  body.replaceChildren();
  if (!placements.length) {
    const row = element('tr');
    const cell = element('td', 'empty-state', '这段时间没有版位。');
    cell.colSpan = 11;
    row.append(cell);
    body.append(row);
    return;
  }
  for (const item of placements) {
    const row = element('tr', item.alert ? 'campaign-alert' : '');
    if (item.alert) row.title = item.alert_reason;
    row.append(
      element('td', '', item.placement),
      element('td', '', number(item.visits)),
      ...funnelCells(item),
      element('td', '', number(item.clicks)),
      element('td', '', number(item.click_times)),
      element('td', '', number(item.opens)),
      element('td', '', percent(item.open_rate)),
      alertCell(item),
    );
    body.append(row);
  }
}

function emptyCampaign(message) {
  const body = $('#campaign-rows');
  body.replaceChildren();
  const row = element('tr');
  const cell = element('td', 'empty-state', message);
  cell.colSpan = 23;
  row.append(cell);
  body.append(row);
}

function flowQuery() {
  const params = new URLSearchParams();
  params.set('range', $('#campaign-range').value || 'today');
  if ($('#campaign-range').value === 'custom') {
    params.set('start', $('#campaign-start').value);
    params.set('end', $('#campaign-end').value);
  }
  const domain = currentDomain();
  if (domain) params.set('domain', domain);
  return params;
}

function fillFlowRows(body, items, span, empty, build) {
  body.replaceChildren();
  if (!items.length) {
    const row = element('tr');
    const cell = element('td', 'empty-state', empty);
    cell.colSpan = span;
    row.append(cell);
    body.append(row);
    return;
  }
  for (const item of items) body.append(build(item));
}

function flowMetricCells(item) {
  return [
    element('td', '', number(item.visits)),
    element('td', '', number(item.clicks)),
    element('td', '', number(item.click_times)),
    element('td', '', number(item.opens)),
    element('td', '', number(item.fallbacks)),
    element('td', '', percent(item.open_rate)),
  ];
}

function renderFlow(data) {
  const alerts = $('#flow-alerts');
  alerts.replaceChildren();
  for (const item of data.alerts || []) {
    const note = element('div', 'notice');
    const text = element('p', '', item.reason);
    note.append(text);
    alerts.append(note);
  }
  const test = data.test || {};
  $('#flow-test').textContent = `测试流量 ${number(test.visits)} 次访问、${number(test.click_times)} 次点击，不计入汇总。`;
  $('#flow-summary').textContent = `报警 ${number((data.alerts || []).length)} 条。进站超过 50 且点击为 0，标红疑似点击或上报失效。版位点击人数至少 10、拉起率比同系统其他版位低 30 个百分点，标红疑似唤醒失败。进站还在、事件连续 15 分钟为 0，标红接收中断。`;
  fillFlowRows($('#flow-systems'), data.systems || [], 7, '这段时间没有计入汇总的进站或点击。', item => {
    const row = element('tr', item.alert ? 'campaign-alert' : '');
    if (item.alert) row.title = item.alert_reason;
    row.append(element('td', '', item.name), ...flowMetricCells(item));
    return row;
  });
  fillFlowRows($('#flow-placements'), data.placements || [], 8, '这段时间没有计入汇总的版位。', item => {
    const row = element('tr', item.alert ? 'campaign-alert' : '');
    if (item.alert) row.title = item.alert_reason;
    row.append(element('td', '', item.name), element('td', '', item.system), ...flowMetricCells(item));
    return row;
  });
  fillFlowRows($('#flow-trend'), data.trend || [], 3, '这段时间没有计入汇总的进站或事件。', item => {
    const row = element('tr', item.alert ? 'campaign-alert' : '');
    if (item.alert) row.title = item.alert_reason || '接收中断';
    row.append(element('td', 'visit-time', item.label), element('td', '', number(item.visits)), element('td', '', number(item.events)));
    return row;
  });
  const shown = (data.visits || []).length;
  const total = data.visits_total || shown;
  $('#flow-visits-summary').textContent = total > shown ? `共 ${number(total)} 次访问，这里显示最近 ${number(shown)} 次。完整名单在访问明细 CSV。` : `共 ${number(total)} 次访问。没有事件的访问会标无事件。`;
  fillFlowRows($('#flow-visits'), data.visits || [], 10, '这段时间没有落地页访问。', item => {
    const row = element('tr');
    row.append(
      element('td', 'visit-time', campaignClock(item.time)),
      element('td', '', item.gclid || '—'),
      element('td', '', item.placement_raw || '—'),
      element('td', '', item.placement_norm || '—'),
      element('td', '', item.system || '—'),
      element('td', '', item.browser || '—'),
      element('td', '', item.number || '—'),
      element('td', '', item.align || '—'),
      element('td', '', item.kind || '—'),
      clipCell(item.chain || '无事件', 'analysis-wide'),
    );
    return row;
  });
  const intakeShown = (data.intake || []).length;
  const intakeTotal = data.intake_total || intakeShown;
  $('#flow-intake-summary').textContent = intakeTotal > intakeShown ? `共 ${number(intakeTotal)} 条请求，这里显示最近 ${number(intakeShown)} 条。完整日志在原始接收 CSV。` : `共 ${number(intakeTotal)} 条请求。空 body、解析失败和被拒绝的也会留下。`;
  fillFlowRows($('#flow-intake'), data.intake || [], 8, '这段时间没有 /wa-events 请求。', item => {
    const row = element('tr', item.status !== 204 ? 'campaign-alert' : '');
    row.append(
      element('td', 'visit-time', campaignClock(item.created)),
      element('td', '', String(item.status ?? '')),
      element('td', '', item.reason || '—'),
      element('td', '', item.ip || '—'),
      element('td', '', item.origin || '—'),
      element('td', '', number(item.body_length)),
      clipCell(item.ua || ''),
      clipCell(item.body || '', 'analysis-wide'),
    );
    return row;
  });
}

function clearFlow(message) {
  $('#flow-summary').textContent = message;
  $('#flow-test').textContent = '';
  $('#flow-alerts').replaceChildren();
  $('#flow-summary-csv').removeAttribute('href');
  $('#flow-visits-csv').removeAttribute('href');
  $('#flow-intake-csv').removeAttribute('href');
  $('#flow-page').removeAttribute('href');
  fillFlowRows($('#flow-systems'), [], 7, message, () => element('tr'));
  fillFlowRows($('#flow-placements'), [], 8, message, () => element('tr'));
  fillFlowRows($('#flow-trend'), [], 3, message, () => element('tr'));
  fillFlowRows($('#flow-visits'), [], 10, message, () => element('tr'));
  fillFlowRows($('#flow-intake'), [], 8, message, () => element('tr'));
  $('#flow-visits-summary').textContent = message;
  $('#flow-intake-summary').textContent = message;
}

async function loadFlow(request) {
  const params = flowQuery();
  const query = params.toString();
  $('#flow-summary-csv').href = `/api/campaign/flow.csv?${query}`;
  $('#flow-visits-csv').href = `/api/campaign/visits.csv?${query}`;
  $('#flow-intake-csv').href = `/api/campaign/intake.csv?${query}`;
  $('#flow-page').href = `/api/campaign/page?domain=${encodeURIComponent(currentDomain())}`;
  try {
    const data = await api(`/api/campaign/flow?${query}`);
    if (request !== campaignRequest) return;
    renderFlow(data);
  } catch (error) {
    if (request === campaignRequest) $('#flow-summary').textContent = '分流汇总加载失败，请再查询一次。';
  }
}

async function loadCampaign() {
  const request = ++campaignRequest;
  const domain = currentDomain();
  if (!domain) {
    $('#campaign-summary').textContent = '请先在左上角选择域名。';
    $('#campaign-note').textContent = '投放数据跟左上角的当前管理站点走。选哪个域名，这里就只显示哪个域名。';
    renderCampaignSystems([]);
    renderCampaignPlacements([]);
    $('#campaign-csv').removeAttribute('href');
    $('#campaign-json').removeAttribute('href');
    const box = $('#campaign-domain');
    if (box) box.value = '';
    emptyCampaign('请先在左上角选择域名。');
    clearFlow('请先在左上角选择域名。');
    return;
  }
  const params = campaignQuery();
  const query = params.toString();
  $('#campaign-csv').href = `/api/campaign.csv?${query}`;
  $('#campaign-json').href = `/api/campaign/events?${query}`;
  const flowDone = loadFlow(request);
  try {
    const data = await api(`/api/campaign?${query}`);
    if (request !== campaignRequest) return;
    const totals = data.totals || {};
    $('#campaign-summary').textContent = `${domain} · 进站 ${number(totals.visits)} · page_view ${number(totals.page_view)} · gate_open ${number(totals.gate_open)} · gate_step2 ${number(totals.gate_step2)} · gate_close ${number(totals.gate_close)} · 点击人数 ${number(totals.clicks)} · 点击次数 ${number(totals.click_times)} · 拉起 ${number(totals.opens)} · 拉起率 ${percent(totals.open_rate)}`;
    $('#campaign-note').textContent = `只显示 ${domain}。同一个 App 的版本号会并成一行，iPhone 和 iPad 应用都写成 iOS App。page_view、gate_open、gate_step2、gate_close 按上报次数单列。点击人数按 gclid 算，同一个人多次点击只算 1 人，点击次数另外显示。拉起按 transaction_id 去重，不超过点击人数。某个版位或系统进站超过 100 且整体点击为 0，或某一行点击至少 30 且拉起率过低，标红列写出原因。同一个版位已经有点击时，其余没点到的行不标红。打开是进来的应用或浏览器，例如微信、华为浏览器、Chrome。接收地址 ${data.endpoint || ''}。时间是香港时间，精确到秒；一行里有多次时显示最晚的一次。进站只算打到源站的 HTML，没有 gclid 时按 IP 和浏览器标识算一人。缓存命中不到源站。标红只提醒，不会自动改页面或跳转。去向是 WhatsApp、BAND 或 Kakao。频道来自 YouTube 网址，视频网址会显示频道名。`;
    renderCampaignSystems(data.systems || []);
    renderCampaignPlacements(data.placements || []);
    if (!data.rows.length) {
      emptyCampaign(`这段时间，${domain} 没有进站或跳转事件。`);
      await flowDone;
      return;
    }
    const body = $('#campaign-rows');
    body.replaceChildren();
    for (const item of data.rows) {
      const row = element('tr', item.alert ? 'campaign-alert' : '');
      if (item.alert) row.title = item.alert_reason;
      const actions = element('td', '', `点击 ${number(item.fallback_click)} · 号码 ${number(item.copy_number)} · 消息 ${number(item.copy_message)}`);
      const flagCell = element('td', '', item.alert ? (item.alert_reason || '是') : '—');
      if (item.alert) {
        const linkParams = new URLSearchParams(params);
        linkParams.set('domain', item.domain);
        linkParams.set('placement', item.placement);
        linkParams.set('placement_exact', '1');
        linkParams.set('wa_env', item.wa_env);
        if (item.dest_app) linkParams.set('dest_app', item.dest_app);
        const link = element('a', 'text-button', '导出该版位');
        link.href = `/api/campaign/events?${linkParams.toString()}`;
        flagCell.append(document.createTextNode(' '));
        flagCell.append(link);
      }
      const when = element('td', 'visit-time', campaignClock(item.seen_at));
      if (item.first_at && item.seen_at && Number(item.first_at) !== Number(item.seen_at)) when.title = `最早 ${campaignClock(item.first_at)}`;
      row.append(
        when,
        element('td', '', item.domain),
        element('td', '', item.dest_label || '未知'),
        element('td', '', item.placement_label),
        element('td', '', item.youtube_label || (item.youtube_video ? `视频 ${item.youtube_video}` : '—')),
        element('td', '', item.opener || '未知'),
        element('td', '', item.device),
        element('td', '', item.wa_env),
        element('td', '', item.link_type),
        element('td', '', `${item.model} · ${item.os}`),
        element('td', '', number(item.visits)),
        ...funnelCells(item),
        element('td', '', number(item.clicks)),
        element('td', '', number(item.click_times)),
        element('td', '', number(item.opens)),
        element('td', '', number(item.fallbacks)),
        element('td', '', percent(item.click_rate)),
        element('td', '', percent(item.open_rate)),
        actions,
        flagCell,
      );
      body.append(row);
    }
  } catch (error) {
    if (request === campaignRequest) $('#campaign-summary').textContent = '加载失败，请再查询一次。';
    throw error;
  } finally {
    await flowDone;
  }
}

async function selectTab(name, {load = true} = {}) {
  if (!labels[name] || (name === 'desk' && isObserver(account))) name = 'overview';
  if (name === 'accounts' && !seesAll(account)) name = 'domains';
  if (!selectedSite && !siteFreeTabs.includes(name)) name = 'domains';
  activeTab = name;
  document.body.dataset.tab = name;
  $$('.tab-panel').forEach(panel => { panel.hidden = panel.id !== `panel-${name}`; });
  $$('[data-tab]').forEach(button => {
    const active = button.dataset.tab === name; button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
  });
  $('#breadcrumb-current').textContent = labels[name][0];
  $('#page-eyebrow').textContent = {overview:'OVERVIEW',domains:'DOMAINS',content:'CONTENT',desk:'WORK ORDERS',rules:'ACCESS RULES',simulate:'SIMULATION',logs:'VISIT LOGS',analysis:'DEEP ANALYSIS',campaign:'CAMPAIGN',speed:'SPEED',accounts:'ACCOUNTS'}[name];
  $('#page-title').textContent = labels[name][1]; $('#page-subtitle').textContent = labels[name][2];
  if (name !== 'content') closePreview();
  else if (state) await Promise.all([tracking.load(), loadPageTitles()]);
  await bRedirects.setActive(name === 'content');
  desk.setActive(name === 'desk');
  if (name === 'logs') await loadLogs();
  if (name === 'analysis') await loadAnalysis();
  if (name === 'campaign') await loadCampaign();
  watchCampaign(name === 'campaign');
  if (name === 'domains' && load) await loadDomains();
  if (name === 'accounts') await loadAccounts();
  if (name === 'overview' && state) dashboard.refresh();
}

on($('#analysis-filters'), 'submit', event => { event.preventDefault(); return loadAnalysis(); });
function selectedMirror() {
  return catalog?.sites.find(item => item.id === selectedSite && item.mirror_source) || null;
}

const analysisClear = $('#analysis-clear');
if (analysisClear) on(analysisClear, 'click', event => busy(event.currentTarget, async () => {
  const domain = currentDomain();
  if (!domain) throw new Error('请先在左上角选择域名。');
  if (selectedMirror()) {
    toast('观察域名只读取投放域名的记录，不能在这里清空。', true);
    return;
  }
  if (!await confirmAction(`删除 ${domain} 的全部请求记录和落地页事件？访问日志不动。删掉后不能恢复，其他域名也不受影响。`)) return;
  const result = await api(`/api/analysis/clear?domain=${encodeURIComponent(domain)}`, { method: 'POST', body: {} });
  toast(`已删除 ${domain} 的 ${number(result.access)} 条请求、${number(result.events)} 条落地页事件。`);
  await loadAnalysis();
}));
on($('#campaign-filters'), 'submit', event => { event.preventDefault(); return loadCampaign(); });
const campaignClear = $('#campaign-clear');
if (campaignClear) on(campaignClear, 'click', event => busy(event.currentTarget, async () => {
  const domain = currentDomain();
  if (!domain) throw new Error('请先在左上角选择域名。');
  if (selectedMirror()) {
    toast('观察域名只读取投放域名的记录，不能在这里清空。', true);
    return;
  }
  if (!await confirmAction(`清空 ${domain} 的全部投放数据？进站请求和落地页事件都会删掉，数据深度分析里这个域名也会空掉。访问日志不动，其他域名也不动。删掉后不能恢复。`)) return;
  const result = await api(`/api/campaign/clear?domain=${encodeURIComponent(domain)}`, { method: 'POST', body: {} });
  toast(`已清空 ${domain} 的 ${number(result.access)} 条进站请求、${number(result.events)} 条落地页事件。`);
  await loadCampaign();
}));
on($('#campaign-range'), 'change', () => {
  const custom = $('#campaign-range').value === 'custom';
  $('#campaign-start-label').hidden = !custom;
  $('#campaign-end-label').hidden = !custom;
});
$$('[data-tab]').forEach(button => on(button, 'click', () => selectTab(button.dataset.tab)));
$$('[data-go]').forEach(button => on(button, 'click', () => selectTab(button.dataset.go)));
on($('.brand'), 'click', event => { event.preventDefault(); return selectTab('overview'); });
on($('#refresh-state'), 'click', event => busy(event.currentTarget, async () => {
  await loadDomains();
  await refreshState();
  if (activeTab === 'logs') await loadLogs(logPage);
  if (activeTab === 'analysis') await loadAnalysis();
  if (activeTab === 'campaign') await loadCampaign();
  if ($('#audit-details').open) await loadAudit();
}));
$$('[data-routing]').forEach(button => on(button, 'click', () => saveConfig(patchConfig(state.config, { routing: button.dataset.routing }))));
$$('[data-allowed-slot]').forEach(button => on(button, 'click', () => saveConfig(patchConfig(state.config, { routing: 'RULES', allowed_slot: button.dataset.allowedSlot }))));
on($('#protection-toggle'), 'click', () => saveConfig(patchConfig(state.config, { protection: !state.config.protection })));
on($('#content-mode'), 'change', event => saveConfig(patchConfig(state.config, { content_mode: event.target.value })));
function openImportRecords() {
  const sites = catalog?.sites || [];
  const watchers = sites.filter(item => item.observer_account);
  if (!watchers.length) {
    toast('还没有观察域名。请先在域名列表把一个域名设为观察域名。', true);
    return;
  }
  if (sites.length < 2) {
    toast('还没有可以导入的来源域名。', true);
    return;
  }
  return new Promise(resolve => {
    const dialog = element('dialog', 'confirm-dialog account-dialog');
    const heading = element('h2', '', '导入数据');
    heading.id = 'import-records-title';
    dialog.setAttribute('aria-labelledby', heading.id);
    const form = element('form');
    const sourceLabel = element('label', '', '来源域名');
    const sourceSelect = element('select');
    sourceSelect.name = 'source_id';
    sourceLabel.append(sourceSelect);
    const observerLabel = element('label', '', '观察域名');
    const observerSelect = element('select');
    observerSelect.name = 'observer_id';
    for (const item of watchers) {
      const option = element('option', '', item.domain || '观察域名');
      option.value = item.id;
      observerSelect.append(option);
    }
    if (watchers.some(item => item.id === selectedSite)) observerSelect.value = selectedSite;
    observerLabel.append(observerSelect);
    const fillSources = () => {
      const previous = sourceSelect.value;
      sourceSelect.replaceChildren();
      for (const item of sites) {
        if (item.id === observerSelect.value) continue;
        const option = element('option', '', item.domain || '原有本地站点');
        option.value = item.id;
        sourceSelect.append(option);
      }
      if ([...sourceSelect.options].some(option => option.value === previous)) sourceSelect.value = previous;
      else if ([...sourceSelect.options].some(option => option.value === selectedSite)) sourceSelect.value = selectedSite;
    };
    fillSources();
    observerSelect.addEventListener('change', fillSources);
    const actions = element('div', 'actions');
    const cancel = element('button', 'button secondary', '取消');
    const save = element('button', 'button primary', '导入数据');
    cancel.type = 'button';
    save.type = 'submit';
    const finish = () => { dialog.close(); dialog.remove(); resolve(); };
    cancel.addEventListener('click', finish);
    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(); });
    on(form, 'submit', async event => {
      event.preventDefault();
      const observerId = observerSelect.value;
      const sourceId = sourceSelect.value;
      if (!observerId || !sourceId || observerId === sourceId) {
        toast('来源域名和观察域名要选两个不同的域名。', true);
        return;
      }
      await busy(save, async () => {
        const result = await api(`/api/sites/${observerId}/import-records`, { method: 'POST', body: { source_id: sourceId }, timeout: 60000 });
        finish();
        await loadDomains();
        if (observerId === selectedSite) {
          await refreshState();
          if (activeTab === 'logs') await loadLogs(logPage);
          if (activeTab === 'analysis') await loadAnalysis();
          if (activeTab === 'campaign') await loadCampaign();
        }
        toast(result.message || '访问记录已导入观察域名。');
      });
    });
    actions.append(cancel, save);
    form.append(sourceLabel, observerLabel, element('p', 'subtle', '只拷访问记录。页面、号码和设置留在来源域名。设置更寻保持原样。'), actions);
    dialog.append(heading, element('p', 'muted', '观察域名自己可以一条记录都没有。'), form);
    document.body.append(dialog);
    dialog.showModal();
    sourceSelect.focus();
  });
}

if ($('#import-records')) on($('#import-records'), 'click', () => openImportRecords());
if ($('#follow-observer')) on($('#follow-observer'), 'click', event => busy(event.currentTarget, async () => {
  if (!selectedSite) {
    toast('请先在左上角选中要跟着的投放域名。', true);
    return;
  }
  const result = await api(`/api/sites/${selectedSite}/follow`, { method: 'POST', body: {} });
  toast(result.message || '观察域名已跟着当前域名。以前的记录都还在。', Boolean(result.sync_failed));
  await loadDomains();
}));
on($('#secret-weapon'), 'click', event => busy(event.currentTarget, async () => {
  if (!state?.slots?.B) {
    toast('还没有发布 B 页。', true);
    return;
  }
  const mode = state.direct_mode;
  const ask = mode === 'ABC'
    ? '填上 ABCABC？只把开关改成 ABCABC，其余代码不动，并清除 Cloudflare 缓存。'
    : mode === 'ABCABC'
      ? '换回选择框？只把开关填成 CBA，其余代码不动，并清除 Cloudflare 缓存。'
      : mode === 'CBA'
        ? '取消弹窗，直接跳 WhatsApp？只把开关填成 ABC，其余代码不动，并清除 Cloudflare 缓存。'
        : '拿掉两步问卷？领取按钮会直接打开 WhatsApp，进线语改成随机两句。跳转方式不变，并清除 Cloudflare 缓存。';
  if (!await confirmAction(ask)) return;
  const result = await api('/api/b-redirects/direct-entry', { method: 'POST', body: { version_id: state.slots.B, expected_published: state.slots.B } });
  const cache = result.cloudflare?.ok ? ' Cloudflare 缓存已清除。' : result.cloudflare ? ' 页面已发布，但 Cloudflare 缓存没清掉。' : '';
  const done = result.kind === 'abcabc' ? '已填上 ABCABC。' : result.kind === 'abc' ? '已填上 ABC，弹窗已去掉。' : result.kind === 'cba' ? '已填上 CBA，选择框已换回。' : '两步问卷已拿掉，进线语改为随机。';
  paintSecretWeapon(result.kind === 'abcabc' ? 'ABCABC' : result.kind === 'abc' ? 'ABC' : result.kind === 'cba' ? 'CBA' : null);
  toast(`${done}${cache}`, Boolean(result.cloudflare && !result.cloudflare.ok));
  await refreshState();
}));
on($('#distribution'), 'change', event => saveConfig(patchConfig(state.config, { distribution: event.target.value })));
on(rulesForm, 'input', () => { editing++; setDirty(true); });
on(rulesForm, 'submit', async event => {
  event.preventDefault();
  if (!state || configBusy) return;
  Object.values(selections).forEach(selection => selection.flush());
  const values = Object.fromEntries(new FormData(rulesForm));
  for (const key of ['super_bots', 'strict_bots', 'block_bots', 'block_pc', 'block_ipv4']) values[key] = rulesForm.elements.namedItem(key).checked;
  await busy(event.submitter, () => saveConfig(rulesConfig(state.config, values), true));
});
on($('#discard-rules'), 'click', async () => {
  if (dirty && !await confirmAction('放弃未保存的规则修改，恢复最近同步的配置？')) return;
  editing++; fillRules();
});
on($('#links-form'), 'submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  await busy(event.submitter, async () => {
    const original = form.elements.urls.value;
    const urls = parseLinks(original);
    await api('/api/links', { method: 'POST', body: { slot: form.elements.slot.value, urls } });
    if (form.elements.urls.value === original) form.elements.urls.value = '';
    toast(`已添加 ${urls.length} 个链接。`); await refreshState();
  });
});
on($('#close-preview'), 'click', closePreview);
on($('#reset-counters'), 'click', event => busy(event.currentTarget, async () => {
  if (!await confirmAction('确认重置访问计数？此操作无法撤销；日志与链接分配计数保持不变。')) return;
  await api('/api/counters/reset', { method: 'POST', body: {} });
  toast('访问计数已重置。'); await refreshState();
}));
on($('#audit-details'), 'toggle', () => { if ($('#audit-details').open) return loadAudit(); });
on($('#refresh-audit'), 'click', event => busy(event.currentTarget, loadAudit));
on($('#simulate-form'), 'submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  await busy(event.submitter, async () => {
    const data = Object.fromEntries(new FormData(form));
    data.ip = data.ip.trim(); data.country = data.country.trim().toUpperCase() || null; data.visits = Number(data.visits);
    const result = await api('/api/simulate', { method: 'POST', body: data });
    const banner = element('div', 'result-banner');
    banner.append(element('h3', '', `展示 ${result.slot} 内容`), element('p', '', reasons[result.reason] || result.reason), element('p', '', `${result.device_details?.device || result.device} · ${countryLabel(result.country)} · 第 ${result.count} 次访问`));
    if (result.device_details) banner.append(element('small', '', `${result.device_details.os} · ${result.device_details.browser}（UA 声明）`));
    const list = element('ol', 'trace-list');
    for (const step of result.trace) {
      const row = element('li', 'trace-row');
      row.append(element('span', `badge ${{ pass: 'green', block: 'red', skip: 'neutral' }[step.status] || 'neutral'}`, { pass: '通过', block: '拦截', skip: '跳过' }[step.status] || step.status));
      const text = element('div'); text.append(element('strong', '', traceLabels[step.rule] || reasons[step.rule] || step.rule), element('small', '', step.detail)); row.append(text); list.append(row);
    }
    $('#simulation-output').replaceChildren(banner, list);
  });
});
on($('#log-filters'), 'submit', event => { event.preventDefault(); return loadLogs(); });
on($('#log-filters'), 'change', () => loadLogs());
on($('#logs-prev'), 'click', () => loadLogs(logPage - 1));
on($('#logs-next'), 'click', () => loadLogs(logPage + 1));
on($('#clear-logs'), 'click', event => busy(event.currentTarget, async () => {
  if (selectedMirror()) {
    toast('观察域名只读取投放域名的记录，不能在这里清空。', true);
    return;
  }
  const domain = currentDomain() || '当前域名';
  if (!await confirmAction(`清空 ${domain} 的全部访问记录？删掉后不能恢复。其他域名不受影响。`)) return;
  const result = await api('/api/logs/clear', { method: 'POST', body: {} });
  toast(`已清空 ${domain} 的 ${number(result.deleted)} 条访问记录。`);
  await refreshState();
  await loadLogs();
}));
on($('#clear-foreign-logs'), 'click', event => busy(event.currentTarget, async () => {
  if (selectedMirror()) {
    toast('观察域名只读取投放域名的记录，不能在这里清空。', true);
    return;
  }
  const domain = currentDomain() || '当前域名';
  if (!await confirmAction(`只删除 ${domain} 里显示成其他国家的访问记录？显示（香港）的会留下，包括以前存成日本、现在显示成香港的。删掉后不能恢复。其他域名不受影响。`)) return;
  const result = await api('/api/logs/clear-foreign', { method: 'POST', body: {} });
  toast(`已删除 ${domain} 的 ${number(result.deleted)} 条非香港记录，留下 ${number(result.kept)} 条显示（香港）的。`);
  await refreshState();
  await loadLogs();
}));
window.addEventListener('beforeunload', event => { if (dirty || sourceEditor.isDirty() || bRedirects.isDirty()) { event.preventDefault(); event.returnValue = ''; } });

const stages = { legacy: '原有站点（保留）', unconfigured: '接入服务未配置', waiting_dns: '等待 DNS 解析', dns_verified: '解析已指向本机，等待建站', creating: '正在创建站点', proxy: '配置入口', certificate: '正在申请证书', verifying: '验收中', active: '已接入', failed: '失败待处理', paused: '已暂停', unsupported: '面板接口待验证' };

const roleLabel = role => ({admin:'总管理员', agent:'代理', observer:'观察号'}[role] || role);

async function loadAccounts() {
  if (!seesAll(account)) return;
  const {items} = await api('/api/accounts');
  const table = element('table','account-table'), head = element('thead'), headings = element('tr'), body = element('tbody');
  for (const label of ['用户名','角色','域名数','状态','操作']) headings.append(element('th','',label));
  head.append(headings); table.append(head,body);
  for (const item of items) {
    const row = element('tr'), status = element('td'), actions = element('td','account-actions');
    const count = item.domain_count ?? catalog?.sites.filter(site=>site.owner_id === item.id).length ?? '—';
    status.append(element('span',`badge ${item.enabled ? 'green' : 'neutral'}`,item.enabled ? '已启用' : '已停用'));
    if (isAdmin(account) && item.role !== 'admin') {
      const kind = item.role === 'observer' ? '观察号' : '代理账号';
      actions.append(actionButton(item.enabled ? '停用' : '启用', async () => {
        if (!await confirmAction(`${item.enabled ? '停用' : '启用'}${kind} ${item.username}？${item.enabled ? '该账号的现有会话会立即退出，域名与数据继续保留。' : '该账号可再次登录。'}`)) return;
        await api(`/api/accounts/${encodeURIComponent(item.id)}`,{method:'PATCH',body:{enabled:!item.enabled}});
        await loadAccounts(); toast(item.enabled ? `${kind}已停用。` : `${kind}已启用。`);
      },'button secondary small'),actionButton('重设密码',()=>resetAccountPassword(item),'text-button small'));
    } else actions.append(element('span','subtle',item.role === 'admin' ? '总管理员' : '只读'));
    row.append(element('td','',item.username),element('td','',roleLabel(item.role)),element('td','',count),status,actions); body.append(row);
  }
  $('#account-list').replaceChildren(table);
}

function resetAccountPassword(item) {
  return new Promise(resolve => {
    const dialog = element('dialog','confirm-dialog account-dialog'), heading = element('h2','','重设密码');
    heading.id='password-dialog-title'; dialog.setAttribute('aria-labelledby',heading.id);
    const form = element('form'), label = element('label','','新密码'), input = element('input');
    input.type='password'; input.name='password'; input.required=true; input.minLength=12; input.maxLength=256; input.autocomplete='new-password'; label.append(input);
    const actions=element('div','actions'), cancel=element('button','button secondary','取消'), save=element('button','button primary','重设密码');
    cancel.type='button'; save.type='submit';
    const finish=()=>{input.value=''; dialog.close(); dialog.remove(); resolve();};
    cancel.addEventListener('click',finish); dialog.addEventListener('cancel',event=>{event.preventDefault();finish();});
    on(form,'submit',async event=>{
      event.preventDefault();
      await busy(save,async()=>{
        await api(`/api/accounts/${encodeURIComponent(item.id)}/password`,{method:'POST',body:{password:input.value}});
        finish(); toast('密码已重设，该账号的现有会话已退出。');
      });
    });
    actions.append(cancel,save); form.append(label,element('p','subtle','12–256 位。成功后请将新密码交给对方。'),actions);
    dialog.append(heading,element('p','muted',item.username),form); document.body.append(dialog); dialog.showModal(); input.focus();
  });
}

async function assignOwner(site) {
  if (!isAdmin(account)) return;
  const {items} = await api('/api/accounts');
  return new Promise(resolve=>{
    const dialog=element('dialog','confirm-dialog account-dialog'), heading=element('h2','','分配域名归属');
    heading.id='owner-dialog-title'; dialog.setAttribute('aria-labelledby',heading.id);
    const form=element('form'), label=element('label','','归属账号'), select=element('select');
    select.name='owner_id'; select.required=true;
    for (const item of items) {
      if (item.role === 'observer') continue;
      const option=element('option','',`${item.username} · ${roleLabel(item.role)}${item.enabled ? '' : '（已停用）'}`); option.value=item.id; select.append(option);
    }
    select.value=site.owner_id; label.append(select);
    const actions=element('div','actions'), cancel=element('button','button secondary','取消'), save=element('button','button primary','保存归属');
    cancel.type='button'; save.type='submit';
    const finish=()=>{dialog.close();dialog.remove();resolve();};
    cancel.addEventListener('click',finish); dialog.addEventListener('cancel',event=>{event.preventDefault();finish();});
    on(form,'submit',async event=>{
      event.preventDefault();
      await busy(save,async()=>{
        await api(`/api/sites/${site.id}/owner`,{method:'PUT',body:{owner_id:select.value}});
        finish();
        if (site.id === selectedSite) clearCurrentSite(selectedSite);
        await loadDomains();
        if (site.id === selectedSite) await refreshState();
        toast('域名归属已更新，新归属立即生效。');
      });
    });
    actions.append(cancel,save); form.append(label,element('p','subtle','转移后原代理无法继续访问此域名及相关数据；页面、规则和记录继续保留。'),actions);
    dialog.append(heading,element('p','muted',site.domain || '原有站点'),form); document.body.append(dialog); dialog.showModal(); select.focus();
  });
}

async function bindMirror(site) {
  if (!isAdmin(account)) return;
  const {items} = await api('/api/accounts');
  const observers = items.filter(item => item.role === 'observer');
  const sources = (catalog?.sites || []).filter(item => item.id !== site.id && !item.mirror_source);
  return new Promise(resolve => {
    const dialog = element('dialog','confirm-dialog account-dialog'), heading = element('h2','','设为观察域名');
    heading.id = 'mirror-dialog-title';
    dialog.setAttribute('aria-labelledby', heading.id);
    const form = element('form');
    const observerLabel = element('label','','观察号'), observerSelect = element('select');
    observerSelect.name = 'observer_id';
    observerSelect.append(element('option','','不绑定'));
    for (const item of observers) {
      const option = element('option','', `${item.username}${item.enabled ? '' : '（已停用）'}`);
      option.value = item.id;
      observerSelect.append(option);
    }
    if (site.observer_account) observerSelect.value = site.observer_account;
    observerLabel.append(observerSelect);
    const sourceLabel = element('label','','投放域名'), sourceSelect = element('select');
    sourceSelect.name = 'source_id';
    sourceSelect.append(element('option','','不绑定'));
    for (const item of sources) {
      const option = element('option','', item.domain || '原有站点');
      option.value = item.id;
      sourceSelect.append(option);
    }
    if (site.mirror_source && sources.some(item => item.id === site.mirror_source)) sourceSelect.value = site.mirror_source;
    sourceLabel.append(sourceSelect);
    const actions = element('div','actions'), cancel = element('button','button secondary','取消'), save = element('button','button primary','保存');
    cancel.type = 'button';
    save.type = 'submit';
    const finish = () => { dialog.close(); dialog.remove(); resolve(); };
    cancel.addEventListener('click', finish);
    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(); });
    on(form, 'submit', async event => {
      event.preventDefault();
      const observerId = observerSelect.value;
      const sourceId = sourceSelect.value;
      if (Boolean(observerId) !== Boolean(sourceId)) {
        toast('观察号和投放域名要一起选，或者一起留空。', true);
        return;
      }
      await busy(save, async () => {
        await api(`/api/sites/${site.id}/mirror`, {method:'PUT', body:{source_id:sourceId, observer_id:observerId}});
        finish();
        await loadDomains();
        if (site.id === selectedSite) await refreshState();
        toast(observerId ? '观察域名已接上。记录会显示成这个域名，页面保持问卷。' : '已取消观察。');
      });
    });
    actions.append(cancel, save);
    form.append(observerLabel, sourceLabel, element('p','subtle','观察号只能看这一个域名。访问记录直接读取投放域名，列表里写的是观察域名。页面、号码和跳转跟着投放域名，观察域名始终是问卷版。'), actions);
    dialog.append(heading, element('p','muted', site.domain || '原有站点'), form);
    document.body.append(dialog);
    dialog.showModal();
    observerSelect.focus();
  });
}

if ($('#account-form')) {
  on($('#refresh-accounts'),'click',loadAccounts);
  on($('#account-form'),'submit',async event=>{
    event.preventDefault(); if (!isAdmin(account)) return;
    const form=event.currentTarget;
    await busy(event.submitter,async()=>{
      const role = form.elements.role?.value === 'observer' ? 'observer' : 'agent';
      await api('/api/accounts',{method:'POST',body:{username:form.elements.username.value.trim(),password:form.elements.password.value,role}});
      form.reset(); form.elements.password.value=''; await loadAccounts(); toast(role === 'observer' ? '观察号已创建。' : '代理账号已创建。');
    });
  });
}

function editSiteNote(site) {
  return new Promise(resolve => {
    const dialog = element('dialog', 'confirm-dialog note-dialog');
    const heading = element('h2', '', '编辑备注'); heading.id = 'note-dialog-title';
    dialog.setAttribute('aria-labelledby', heading.id);
    const form = element('form'), label = element('label', '', '备注');
    const input = element('textarea'); input.name = 'note'; input.rows = 3; input.maxLength = 200; input.value = site.note || '';
    input.placeholder = '例如：韩国手机流量 / 第 2 组测试';
    label.append(input);
    const actions = element('div', 'actions');
    const cancel = element('button', 'button secondary', '取消'); cancel.type = 'button';
    const save = element('button', 'button primary', '保存备注'); save.type = 'submit';
    const finish = () => { dialog.close(); dialog.remove(); resolve(); };
    cancel.addEventListener('click', finish);
    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(); });
    on(form, 'submit', async event => {
      event.preventDefault();
      await busy(save, async () => {
        await api(`/api/sites/${site.id}/metadata`, {method:'PATCH',body:{note:input.value}});
        finish(); await loadDomains(); toast('备注已保存。');
      });
    });
    actions.append(cancel, save); form.append(label, element('p', 'subtle', '最多 200 字，仅管理后台可见。'), actions);
    dialog.append(heading, element('p', 'muted', site.domain || '原有本地站点'), form);
    document.body.append(dialog); dialog.showModal(); input.focus();
  });
}

async function showSiteEvents(site) {
  const request = ++siteEventsRequest;
  siteEventsSite = site.id;
  const data = await api(`/api/sites/${site.id}/provision/events`);
  if (request !== siteEventsRequest) return;
  $('#provision-events-title').textContent = `${site.domain || '原有站点'} · 操作日志`;
  $('#provision-events').replaceChildren(...(data.items.length
    ? data.items.map(item => element('p', 'subtle', `${formatDate(item.created)} · ${stages[item.stage] || item.stage} · ${item.detail}`))
    : [element('p', 'subtle', '暂无操作记录。')]));
  $('#provision-events-panel').hidden = false;
  $('#provision-events-panel').scrollIntoView({behavior:'smooth',block:'nearest'});
}

function renderReputation(site, cell) {
  const reputation = site.google_reputation;
  const display = reputationChecking.has(site.id) ? {label:'检测中…',tone:'neutral'} : reputationView(reputation);
  const badge = element('span',`domain-health badge ${display.tone}`,display.label);
  badge.title = reputation?.detail || '尚无谷歌检测结果';
  cell.replaceChildren(badge);
  if (display.tone === 'red') cell.append(element('small','domain-detail',(reputation.threats || []).map(kind=>({MALWARE:'恶意软件',SOCIAL_ENGINEERING:'钓鱼欺诈',UNWANTED_SOFTWARE:'不受欢迎的软件'})[kind] || kind).join(' · ')));
  if (reputation?.checked_at) cell.append(element('small','domain-detail',formatDate(reputation.checked_at)));
  else cell.append(element('small','domain-detail',reputation?.status === 'unconfigured' ? isAdmin(account) ? '等待 API 配置' : '检测未启用 · 联系管理员' : reputationChecking.has(site.id) ? '正在查询谷歌' : '自动检测'));
}

function renderDomains() {
  if (!catalog) return;
  const all = catalog.sites;
  const online = all.filter(site => site.enabled && ['active','legacy'].includes(site.stage)).length;
  const offline = all.filter(site => !site.enabled).length;
  $('#domains-summary').replaceChildren(...[
    [seesAll(account) ? '全部域名' : '我的域名',all.length],['已上线',online],['待接入',all.length-online-offline],['已下线',offline],
  ].map(([label,count]) => {const item = element('span'); item.append(element('strong','',count),document.createTextNode(` ${label}`)); return item;}));
  const query = $('#domain-search').value.trim().toLowerCase();
  const sites = all.filter(site => `${site.domain} ${site.note || ''}`.toLowerCase().includes(query));
  const table = element('table','domain-table');
  const head = element('thead'), headings = element('tr'), body = element('tbody');
  for (const name of ['域名','谷歌安全检测','接入状态','添加日期','备注','状态','操作']) headings.append(element('th','',name));
  head.append(headings); table.append(head,body);
  for (const site of sites) {
    const row = element('tr'), name = element('td'), health = element('td'), validation = element('td'), created = element('td'), note = element('td'), availability = element('td'), actions = element('td');
    name.append(element('strong','domain-name',site.domain || '原有本地站点'), element('small','domain-detail',site.id === 'default' ? '原有站点' : '自带域名'));
    if (site.cf_status) {
      const checking = cloudflareChecking.has(site.id);
      const [label, tone] = checking ? ['检查中', 'neutral'] : {active:['有效','green'], pending:['待处理','neutral'], failed:['未完成','red']}[site.cf_status] || ['Cloudflare','neutral'];
      const badge = element('span', `domain-health badge ${tone}`, `Cloudflare ${label}`);
      badge.dataset.cfSite = site.id;
      name.append(badge);
    }
    if (seesAll(account)) {
      const owner = element('div','domain-owner');
      owner.append(element('small','domain-detail',`归属：${site.owner_username || '总管理员'}`));
      if (isAdmin(account)) owner.append(actionButton('分配',()=>assignOwner(site),'text-button small'));
      name.append(owner);
    }
    if (isAdmin(account) && site.mirror_source) name.append(element('small','domain-detail',`观察域名 · 读取 ${site.mirror_domain || '投放域名'} 的记录，页面保持问卷`));
    health.dataset.reputationSite = site.id;
    renderReputation(site,health);
    const healthText = site.stage === 'active' ? '已验收' : ['failed','unsupported'].includes(site.stage) ? '需处理' : site.stage === 'legacy' ? '待核验' : '接入中';
    const healthColor = site.stage === 'active' ? 'green' : ['failed','unsupported'].includes(site.stage) ? 'red' : 'neutral';
    validation.append(element('span',`domain-health badge ${healthColor}`,healthText));
    const detail = element('small','domain-detail',stages[site.stage] || site.stage);
    detail.title = (site.error || '基于已有接入记录，非实时探测') + (site.enabled && site.next_attempt && site.stage!=='active' ? `；下次检查：${formatDate(site.next_attempt)}` : ''); validation.append(detail);
    if (site.error && site.stage !== 'active') { const error = element('small',`domain-detail${['failed','unsupported'].includes(site.stage)?' domain-error':''}`,site.error.length>52 ? site.error.slice(0,52)+'…' : site.error); error.title=site.error; validation.append(error); }
    const dnsPassed = ['active','dns_verified','creating','proxy','certificate','verifying'].includes(site.stage);
    validation.append(element('small','domain-detail',`${dnsPassed ? 'DNS 已验证' : 'DNS 未确认'} · ${site.stage === 'active' ? '证书已验收' : '证书未确认'}`));
    if (site.cf_nameservers && site.cf_status === 'pending') validation.append(element('small','domain-detail',`NS：${site.cf_nameservers.split(',').join('、')} · 本页会自动检查，生效后变为「有效」`));
    if ((site.cf_zone_id || site.cf_status) && site.id !== 'default' && !['active','legacy'].includes(site.stage)) validation.append(element('small','domain-detail','要走宝塔自动建站：点「关闭 Cloudflare」，再把 A 记录指到本机。'));
    if (catalog.cloudflare_configured && site.stage === 'active' && !site.cf_status && site.id !== 'default') validation.append(element('small','domain-detail','证书已接入。确认网站能打开后，点「套用 Cloudflare」，再把注册商 NS 改成页面给出的两条。'));
    const date = site.created ? new Date(site.created*1000) : null;
    created.append(element('span','',date ? date.toLocaleDateString('zh-CN') : '—'));
    created.title = date ? formatDate(site.created) : '登记时间未知';
    const memo = element('span','domain-note',site.note || '—'); memo.title = site.note || '暂无备注';
    note.append(memo);
    if (!isObserver(account)) note.append(actionButton('编辑',()=>editSiteNote(site),'text-button small'));
    const live = site.enabled && ['active','legacy'].includes(site.stage);
    availability.append(element('span',`domain-status ${!site.enabled?'offline':live?'online':'pending'}`,!site.enabled?'已下线':live?'已上线':'待接入'));
    actions.className='domain-actions';
    actions.append(actionButton(site.id===selectedSite?'当前站点':'管理',()=>switchSite(site.id),'button secondary small'));
    if (!isObserver(account) && site.cf_zone_id && site.id !== 'default') {
      const mode = Number(site.cf_challenge) || 0;
      const challenge = element('span', 'domain-challenge');
      challenge.append(element('span', 'domain-challenge-title', '人机验证'));
      const entryOn = Boolean(mode & 1);
      const buttonOn = Boolean(mode & 2);
      challenge.append(humanSwitch(site, '进入落地', entryOn, async () => {
        const result = await api(`/api/sites/${site.id}/cloudflare/challenge`, {method:'POST', body:{entry:!entryOn, button:buttonOn}, timeout:60000});
        await loadDomains();
        toast(result.detail);
      }));
      challenge.append(humanSwitch(site, '点击按钮', buttonOn, async () => {
        const result = await api(`/api/sites/${site.id}/cloudflare/challenge`, {method:'POST', body:{entry:entryOn, button:!buttonOn}, timeout:60000});
        await loadDomains();
        toast(result.detail);
      }));
      actions.append(challenge);
    }
    if (!isObserver(account)) actions.append(actionButton(site.enabled?'下线':'上线',async()=>{
      const action = site.enabled ? 'offline' : 'online';
      if (site.enabled && !await confirmAction(`下线 ${site.domain || '原有站点'}？访客将无法继续访问；页面、规则和历史数据都会保留。`)) return;
      await api(`/api/sites/${site.id}/availability/${action}`,{method:'POST',body:{}});
      await loadDomains();
      if (site.id === selectedSite) await refreshState();
      toast(site.enabled ? '域名已下线。' : ['active','legacy'].includes(site.stage) ? '域名已上线。' : '已启用域名并重试接入，DNS 与证书仍待验收。');
    },`button ${site.enabled?'secondary':'primary'} small`));
    actions.append(actionButton('日志',()=>showSiteEvents(site),'text-button small'));
    if (!isObserver(account) && site.id !== 'default' && site.enabled && !['active','legacy'].includes(site.stage)) actions.append(actionButton('重试',async()=>{
      await api(`/api/sites/${site.id}/provision/retry`,{method:'POST',body:{}}); await loadDomains();
    },'text-button small'));
    if (!isObserver(account) && site.cf_zone_id) actions.append(actionButton('清除 CF 缓存',async()=>{
      await api(`/api/sites/${site.id}/cloudflare/purge`,{method:'POST',body:{}});
      toast(`已清除 ${site.domain} 的 Cloudflare 缓存。`);
    },'button secondary small'));
    if (!isObserver(account) && (site.cf_zone_id || site.cf_status) && site.id !== 'default') actions.append(actionButton('关闭 Cloudflare',async()=>{
      const ip = catalog.server_ip || '本机公网 IP';
      const message = ['active','legacy'].includes(site.stage)
        ? `关闭 ${site.domain} 的 Cloudflare 橙色云？访客会直接走到现在的 A 记录，本机站点和证书保持不变。`
        : `关闭 ${site.domain} 的 Cloudflare 橙色云？关掉后请把 A 记录指到 ${ip}。注册商 NS 如果仍是 Cloudflare 的两条，改 Cloudflare 里的 A 记录；改回注册商 NS 后，再在注册商把 A 记录指到 ${ip}。指向本机后会自动在宝塔建站并申请证书。`;
      if (!await confirmAction(message)) return;
      const result = await api(`/api/sites/${site.id}/cloudflare/disable`,{method:'POST',body:{},timeout:60000});
      await loadDomains();
      const address = result.record_address || '';
      let note = result.cloudflare?.detail || '已关闭 Cloudflare 代理。';
      if (address && ip && address === catalog.server_ip) note += ` Cloudflare 里的 A 记录已经是 ${address}，橙色云关掉后公共解析会指向本机。`;
      else if (address && catalog.server_ip) note += ` Cloudflare 里的 A 记录仍是 ${address}，请改成 ${catalog.server_ip}。`;
      toast(note);
    },'button secondary small'));
    if (!isObserver(account) && catalog.cloudflare_configured && site.stage === 'active' && !site.cf_status && site.id !== 'default') actions.append(actionButton('套用 Cloudflare',async()=>{
      const result = await api(`/api/sites/${site.id}/cloudflare`,{method:'POST',body:{},timeout:60000});
      await loadDomains();
      const servers = (result.cloudflare?.nameservers || []).join('、');
      toast(result.cloudflare?.ok ? (servers ? `已套用 Cloudflare。请把注册商 NS 改为：${servers}` : '已套用 Cloudflare。请按提示修改 NS。') : (result.cloudflare?.detail || 'Cloudflare 未完成'), !result.cloudflare?.ok);
    },'button primary small'));
    if (!isObserver(account) && site.cf_status === 'failed') actions.append(actionButton('重试 CF',async()=>{
      const result = await api(`/api/sites/${site.id}/cloudflare`,{method:'POST',body:{},timeout:60000});
      await loadDomains();
      toast(result.cloudflare?.ok ? '已重新套用 Cloudflare 规则。' : (result.cloudflare?.detail || 'Cloudflare 未完成'), !result.cloudflare?.ok);
    },'text-button small'));
    if (isAdmin(account)) actions.append(actionButton(site.mirror_source ? '调整观察' : '设为观察', () => bindMirror(site), 'text-button small'));
    if (isAdmin(account) && site.id !== 'default') actions.append(actionButton('彻底删除',async()=>{
      const watchers = (catalog?.sites || []).filter(item => item.observer_account && item.id !== site.id);
      let keep = false;
      if (watchers.length && !site.observer_account) {
        const choice = await chooseKeptRecords(site.domain || '这个域名', watchers);
        if (choice === null) return;
        keep = choice;
      } else if (!await confirmAction(`彻底删除 ${site.domain}？页面、证书、访问记录和宝塔站点都会删掉，域名列表和上方的站点选择也会一起消失，删了不能恢复。`)) return;
      const result = await api(`/api/sites/${site.id}?keep_records=${keep ? 'true' : 'false'}`,{method:'DELETE'});
      await loadDomains();
      const kept = (result.kept || []).map(item => item.domain).filter(Boolean).join('、');
      const keptNote = kept ? `访问记录已留在 ${kept}。` : '';
      const warning = result.cloudflare_warning ? `${result.cloudflare_warning}` : '';
      toast([`已彻底删除 ${result.domain}。`, keptNote, warning].filter(Boolean).join(''), Boolean(warning));
    },'text-button small danger'));
    row.append(name,health,validation,created,note,availability,actions); body.append(row);
  }
  if (!sites.length) { const row=element('tr'), cell=element('td','empty-state',all.length ? '没有匹配的域名或备注' : '暂无域名，点击「添加域名」开始接入。'); cell.colSpan=7; row.append(cell); body.append(row); }
  $('#domain-list').replaceChildren(table);
}

async function loadDomains({refreshSelection = true} = {}) {
  const request = ++domainsRequest;
  const result = await api('/api/sites');
  if (request !== domainsRequest) return;
  if (result.google_reputation_configured) for (const site of result.sites) {
    const recent = latestReputation.get(site.id);
    if (recent?.checked_at > (site.google_reputation?.checked_at || 0)) site.google_reputation = recent;
  }
  catalog = result;
  account = result.account;
  const next = chooseSite(selectedSite, catalog.sites);
  const changed = next !== selectedSite;
  if (changed || !next) clearCurrentSite(next);
  $('#no-sites').hidden = Boolean(next);
  if (!next) { $('#connection').textContent='服务已连接'; $('#connection').className='badge green'; }
  $('#refresh-state').disabled = !next;
  $$('[data-tab], [data-go]').forEach(button => {
    const tab = button.dataset.tab || button.dataset.go;
    button.disabled = (!next && !siteFreeTabs.includes(tab)) || (tab === 'accounts' && !seesAll(account));
  });
  $('#site-selector-label').textContent = seesAll(account) ? '当前管理站点' : '我的域名';
  $('#analytics-scope').querySelector('[value="all"]').textContent = seesAll(account) ? '所有域名' : '我的域名';
  $('#google-reputation-notice').textContent = catalog.google_reputation_configured
    ? '自动检测已开启 · 本页停留时检查未检测或已过期的域名，结果直接显示在下方。'
    : isAdmin(account) ? '自动检测待启用：请先配置 Google Web Risk API 密钥，完成后本页自动显示结果。' : '检测未启用，请联系管理员。';
  const selector = $('#site-selector'); selector.replaceChildren();
  for (const site of catalog.sites) {
    const option = element('option', '', site.domain || '原有本地站点'); option.value = site.id; selector.append(option);
  }
  if (!next) { const option = element('option','','暂无域名'); option.value=''; selector.append(option); }
  selector.value = selectedSite;
  syncCopyDomain();
  const cloudflareReady = Boolean(catalog.cloudflare_configured);
  $('#cf-choice').hidden = !cloudflareReady;
  $('#cf-choice-note').hidden = !cloudflareReady;
  if (!cloudflareReady) $('#use-cloudflare').checked = false;
  const templateName = catalog.cloudflare_template ? `「${catalog.cloudflare_template}」上的` : '已配置的';
  $('#cf-choice-note').textContent = cloudflareReady ? `建议先不勾选：A 记录指向本机后会自动建站并申请证书，确认能打开后再套用${templateName}规则。勾选则马上套用规则，NS 改到 Cloudflare。` : '';
  syncDnsInstructions();
  renderDomains();
  paintFollowStatus();
  const visible = new Set(catalog.sites.map(site=>site.id));
  if (siteEventsSite && !visible.has(siteEventsSite)) {
    ++siteEventsRequest; siteEventsSite=null;
    $('#provision-events').replaceChildren(); $('#provision-events-panel').hidden=true;
  }
  for (const id of latestReputation.keys()) if (!visible.has(id)) latestReputation.delete(id);
  for (const id of reputationChecking) if (!visible.has(id)) reputationChecking.delete(id);
  for (const id of cloudflareChecking) if (!visible.has(id)) cloudflareChecking.delete(id);
  reputationAutoCheck.refresh(catalog).catch(()=>{});
  cloudflareAutoCheck.refresh(catalog).catch(()=>{});
  updateSiteLock();
  if (!next && !siteFreeTabs.includes(activeTab)) await selectTab('domains',{load:false});
  if (changed && next && refreshSelection) {
    await refreshState();
    if (activeTab === 'logs') await loadLogs();
    if (activeTab === 'analysis') await loadAnalysis();
    if (activeTab === 'campaign') await loadCampaign();
  }
}

function clearCurrentSite(next) {
  sourceEditor.clear();
  bRedirects.clear();
  selectedSite = next;
  ++stateRequest; ++logsRequest; ++siteEventsRequest; closePreview(); dashboard.invalidate();
  siteEventsSite=null;
  state = null; setDirty(false); editing++;
  rulesForm.reset(); Object.values(selections).forEach(selection=>selection.set([]));
  $('#links-form').reset(); $('#simulate-form').reset(); $('#log-filters').reset();
  for (const id of ['rules-fields','links-fields','simulate-fields','reset-counters']) $(`#${id}`).disabled=true;
  for (const id of ['slot-cards','links-list','audit-list','logs-body','provision-events']) $(`#${id}`).replaceChildren();
  $('#audit-details').open=false; $('#provision-events-panel').hidden=true;
  $('#export-logs').removeAttribute('href'); $('#open-target').removeAttribute('href');
  $('#open-target').hidden=true;
  $('#link-count').textContent='0 个链接'; $('#logs-summary').textContent=''; $('#logs-page').textContent='—';
  $('#logs-prev').disabled=true; $('#logs-next').disabled=true;
  $('#simulation-output').replaceChildren(element('p','empty-state','请为当前站点重新运行模拟。'));
  $('#analytics-retention').textContent=''; $('#geoip-warning').hidden=true; $('#load-error').hidden=true;
  for (const id of ['geoip-status','current-mode','published-count','last-sync','allowed-slot-badge','allowed-content-status','overview-allowed-status']) $(`#${id}`).textContent='—';
  $('#hero-mode').textContent=next ? '正在读取当前站点…' : '暂无域名';
  $('#hero-title').textContent=next ? '正在切换站点' : '添加你的第一个域名';
  $('#hero-description').textContent=''; $('#sidebar-theme').textContent=next ? '主题加载中' : '等待添加域名';
  $('#site-context').textContent=next ? '正在加载独立配置…' : '添加域名后即可管理内容与访问规则。';
  $$('.tab-panel').forEach(panel=>{panel.inert=!alwaysOpenPanels.includes(panel.id);});
  updateConfigControls();
}

function currentDomain() {
  const selector = $('#site-selector');
  return catalog?.sites?.find(site => site.id === selector.value)?.domain || '';
}

function syncCopyDomain() {
  const button = $('#copy-domain');
  const domain = currentDomain();
  const fallback = $('#site-selector').selectedOptions[0]?.textContent || '暂无域名';
  button.textContent = domain || fallback;
  button.disabled = !domain;
  button.title = domain ? `点击复制 ${domain}` : '当前站点没有可复制的域名';
  button.setAttribute('aria-label', domain ? `复制域名 ${domain}` : '当前站点没有可复制的域名');
}

async function copyText(value) {
  if (navigator.clipboard?.writeText) {
    try { await navigator.clipboard.writeText(value); return; }
    catch { /* Fall through when the page is not a secure context. */ }
  }
  const area = element('textarea');
  area.value = value; area.setAttribute('readonly', '');
  area.style.position = 'fixed'; area.style.left = '-9999px';
  document.body.append(area); area.select();
  const copied = document.execCommand('copy');
  area.remove();
  if (!copied) throw new Error('复制失败，请手动选择域名。');
}

async function switchSite(next) {
  if (next === selectedSite) return;
  if (!catalog?.sites.some(site=>site.id === next)) return;
  if (configBusy || pendingActions > 1 || siteLoading) { $('#site-selector').value = selectedSite; syncCopyDomain(); return; }
  const hasDraft = dirty || sourceEditor.isDirty() || bRedirects.isDirty() || $('#links-form').elements.urls.value.trim() || $$('.upload-form input[type=file]').some(input => input.files.length);
  if (hasDraft && !await confirmAction('切换站点将丢弃尚未保存的规则、源码、链接草稿和选中的上传文件，是否继续？')) { $('#site-selector').value = selectedSite; syncCopyDomain(); return; }
  siteLoading = true; updateSiteLock();
  clearCurrentSite(next); $('#site-selector').value = next; syncCopyDomain();
  try {
    await refreshState();
    if (activeTab === 'logs') await loadLogs();
    if (activeTab === 'analysis') await loadAnalysis();
    if (activeTab === 'campaign') await loadCampaign();
    visitWatch.checkRate();
    if ($('#audit-details').open) await loadAudit();
  } finally {
    siteLoading = false; updateSiteLock();
    $$('.tab-panel').forEach(panel => { panel.inert = !state && !alwaysOpenPanels.includes(panel.id); });
    if (!state && selectedSite) { $('#open-target').removeAttribute('href'); $('#site-context').textContent = '当前站点加载失败，请刷新状态或切换其他站点。'; }
  }
}

on($('#site-selector'), 'change', event => switchSite(event.target.value));
on($('#copy-domain'), 'click', async () => {
  const domain = currentDomain();
  if (!domain) throw new Error('当前站点没有可复制的域名。');
  await copyText(domain);
  toast(`已复制 ${domain}`);
});
on($('#refresh-domains'), 'click', loadDomains);
on($('#domain-search'), 'input', renderDomains);
function syncDnsInstructions() {
  const box = $('#use-cloudflare');
  if (box && !box.closest('#cf-choice').hidden && box.checked) {
    $('#dns-instructions').textContent = '添加后会在 Cloudflare 建这个域名，并套用现有优化规则。请把注册商 NS 改成页面给出的两条。';
    return;
  }
  $('#dns-instructions').textContent = catalog?.server_ip
    ? `先把 A 记录指到 ${catalog.server_ip}，再点建立域名。程序会自动建站并申请证书。网站能打开后，再点「套用 Cloudflare」。`
    : '服务器公网 IP 尚未配置；现在可以登记域名和测试独立配置，但不能自动建站或申请证书。';
}

on($('#new-domain'), 'click', () => { $('#domain-add-panel').hidden=false; $('#domain-add-panel').scrollIntoView({behavior:'smooth',block:'nearest'}); $('#domain-form').elements.domain.focus(); });
on($('#empty-add-domain'), 'click', async () => { await selectTab('domains'); $('#new-domain').click(); });
on($('#cancel-domain-add'), 'click', () => { $('#domain-add-panel').hidden=true; });
on($('#use-cloudflare'), 'change', syncDnsInstructions);
on($('#domain-form'), 'submit', async event => {
  event.preventDefault(); const form = event.currentTarget;
  const useCloudflare = !$('#cf-choice').hidden && $('#use-cloudflare').checked;
  await busy(event.submitter, async () => {
    const result = await api('/api/sites', { method: 'POST', body: useCloudflare ? { domain: form.elements.domain.value.trim(), cloudflare: true } : { domain: form.elements.domain.value.trim() }, timeout: 60000 });
    form.reset(); $('#cf-result').hidden = true;
    await loadDomains();
    if (result.cloudflare?.ok) {
      const servers = (result.cloudflare.nameservers || []).join('、');
      $('#cf-result').hidden = false;
      $('#cf-result').textContent = servers ? `${result.cloudflare.detail} NS：${servers}` : result.cloudflare.detail;
      toast('已套用 Cloudflare 规则。请按提示修改 NS。');
    } else if (result.cloudflare) {
      $('#cf-result').hidden = false;
      $('#cf-result').textContent = result.cloudflare.detail;
      toast(result.cloudflare.detail, true);
    } else toast('域名已登记。A 记录指向本机后，会自动建站并申请证书。');
  });
});

let speedToken = 0;
let speedBusy = false;
let speedHasRun = false;

function speedMs(value) {
  if (value === null || value === undefined || value === '') return '—';
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '—';
  return amount >= 100 ? `${Math.round(amount)}ms` : `${amount.toFixed(1)}ms`;
}

function speedBytes(value) {
  if (value === null || value === undefined || value === '') return '—';
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '—';
  if (amount < 1024) return `${Math.round(amount)} B`;
  if (amount < 1024 * 1024) return `${(amount / 1024).toFixed(1)} KB`;
  return `${(amount / 1024 / 1024).toFixed(1)} MB`;
}

function scoreTone(score) {
  if (score >= 90) return 'good';
  if (score >= 50) return 'mid';
  return 'poor';
}

function setSpeedBusy(busy) {
  speedBusy = busy;
  $('#speed-start').disabled = busy;
  $('#speed-again').disabled = busy || !speedHasRun;
  for (const id of ['speed-url', 'speed-region', 'speed-repeats', 'speed-strategy', 'speed-use-domain']) $(`#${id}`).disabled = busy;
}

function renderSpeed(job) {
  const status = $('#speed-status');
  if (job.status === 'running') status.textContent = `正在检测第 ${job.completed + 1} / ${job.repeats} 次 · ${job.region_label}网速，以及 Google 实验室的${job.strategy_label}评分`;
  else if (job.status === 'done') status.textContent = `${job.repeats} 次已完成。${job.pagespeed_note}${job.probe_note}`;
  else status.textContent = job.error || '检测中断';
  const summary = $('#speed-summary');
  summary.replaceChildren();
  if (!job.summary || (job.summary.score_avg === null && job.summary.total_ms_avg === null)) summary.hidden = true;
  else {
    summary.hidden = false;
    if (job.summary.score_avg !== null) {
      const card = element('article', 'stat-card');
      const label = element('div', 'stat-label');
      label.append(element('span', '', '平均性能评分'));
      card.append(label, element('strong', `speed-score ${scoreTone(job.summary.score_avg)}`, String(job.summary.score_avg)), element('p', '', `${job.summary.score_count} 次${job.strategy_label}评分`));
      summary.append(card);
    }
    if (job.summary.total_ms_avg !== null) {
      const card = element('article', 'stat-card');
      const label = element('div', 'stat-label');
      label.append(element('span', '', '平均总响应'));
      card.append(label, element('strong', '', speedMs(job.summary.total_ms_avg)), element('p', '', `${job.summary.probe_count} 次${job.region_label}探测`));
      summary.append(card);
    }
  }
  const body = $('#speed-rows');
  body.replaceChildren();
  if (!job.runs.length) {
    const row = element('tr');
    const cell = element('td', 'empty-state', job.status === 'running' ? '正在等待第一次结果…' : '还没有检测结果。');
    cell.colSpan = 17;
    row.append(cell);
    body.append(row);
    return;
  }
  for (const run of job.runs) {
    const row = element('tr');
    const score = element('td');
    if (run.pagespeed) {
      score.append(element('strong', `speed-score ${scoreTone(run.pagespeed.score)}`, String(run.pagespeed.score)));
      if (run.pagespeed.source_label) score.append(element('small', '', run.pagespeed.source_label));
    }
    else score.textContent = run.pagespeed_error || '—';
    const place = element('td');
    if (run.probe) {
      place.append(document.createTextNode([job.region_label, run.probe.city].filter(Boolean).join(' · ') || job.region_label));
      if (run.probe.network) place.append(element('small', '', run.probe.network));
    } else place.textContent = run.probe_error || '—';
    const metrics = run.pagespeed || {};
    row.append(
      element('td', '', String(run.index)),
      score,
      element('td', '', speedMs(metrics.fcp_ms)),
      element('td', '', speedMs(metrics.lcp_ms)),
      element('td', '', speedMs(metrics.tbt_ms)),
      element('td', '', metrics.cls === null || metrics.cls === undefined ? '—' : Number(metrics.cls).toFixed(3)),
      element('td', '', speedMs(metrics.si_ms)),
      place,
      element('td', 'ip-cell', run.probe?.ip || '—'),
      element('td', '', run.probe?.status ?? '—'),
      element('td', '', speedMs(run.probe?.total_ms)),
      element('td', '', speedMs(run.probe?.dns_ms)),
      element('td', '', speedMs(run.probe?.tcp_ms)),
      element('td', '', speedMs(run.probe?.tls_ms)),
      element('td', '', speedMs(run.probe?.first_byte_ms)),
      element('td', '', speedMs(run.probe?.download_ms)),
      element('td', '', speedBytes(run.probe?.bytes)),
    );
    body.append(row);
  }
}

async function watchSpeed(id, token) {
  while (token === speedToken) {
    const job = await api(`/api/speedcheck/${id}`);
    if (token !== speedToken) return;
    renderSpeed(job);
    if (job.status !== 'running') return;
    await new Promise(resolve => window.setTimeout(resolve, 1200));
  }
}

async function runSpeedCheck() {
  const token = ++speedToken;
  const body = {
    url: $('#speed-url').value.trim(),
    region: $('#speed-region').value,
    repeats: Number($('#speed-repeats').value),
    strategy: $('#speed-strategy').value,
  };
  setSpeedBusy(true);
  $('#speed-status').textContent = '正在开始…';
  try {
    const job = await api('/api/speedcheck', { method: 'POST', body });
    if (token !== speedToken) return;
    speedHasRun = true;
    renderSpeed(job);
    await watchSpeed(job.id, token);
  } catch (error) {
    if (token !== speedToken || error.stale) return;
    $('#speed-status').textContent = error.detail || error.message;
  } finally {
    if (token === speedToken) setSpeedBusy(false);
  }
}

on($('#speed-form'), 'submit', event => {
  event.preventDefault();
  if (speedBusy) return;
  speedBusy = true;
  void runSpeedCheck();
});
on($('#speed-again'), 'click', () => {
  if (speedBusy) return;
  $('#speed-form').requestSubmit();
});
on($('#speed-use-domain'), 'click', () => {
  const domain = currentDomain();
  if (!domain) {
    toast('左上角没有可选的域名。', true);
    return;
  }
  $('#speed-url').value = `https://${domain}/`;
});

if (isObserver(account)) {
  document.addEventListener('submit', event => {
    if (event.target?.id === 'log-filters' || event.target?.id === 'analysis-filters' || event.target?.id === 'speed-form') return;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  for (const id of ['new-domain', 'empty-add-domain', 'clear-logs', 'clear-foreign-logs']) {
    const node = document.getElementById(id);
    if (node) node.hidden = true;
  }
}
document.body.dataset.tab = 'overview';
renderSlots();
loadDomains({refreshSelection:false}).then(async () => { await refreshState(); visitWatch.checkRate(); }).catch(error => toast(error.message, true)).finally(() => { siteLoading = false; updateSiteLock(); });
window.setInterval(() => { if (!document.hidden && !pendingActions) loadDomains().catch(() => {}); }, 15000);
document.addEventListener('visibilitychange',()=>{ if (!document.hidden) loadDomains().catch(()=>{}); });
