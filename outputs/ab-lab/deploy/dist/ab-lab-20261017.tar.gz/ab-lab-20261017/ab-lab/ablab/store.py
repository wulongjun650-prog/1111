import hashlib
import hmac
import ipaddress
import json
import re
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
import secrets
import shutil
import sqlite3
import time

from .models import Config
from .archives import edit_content


class Conflict(ValueError):
    pass


_JUMP_KINDS = {
    'whatsapp_click': 'click',
    'band_click': 'click',
    'kakao_click': 'click',
    'wa_app_opened': 'open',
    'band_app_opened': 'open',
    'kakao_app_opened': 'open',
    'wa_fallback_shown': 'fallback',
    'band_fallback_shown': 'fallback',
    'kakao_fallback_shown': 'fallback',
}
_JUMP_COLUMNS = ('click', 'open', 'fallback')
_DEST_LABELS = {'whatsapp': 'WhatsApp', 'band': 'BAND', 'kakao': 'Kakao'}


def _jump_dest(payload):
    raw = _event_text(payload.get('dest_app')).lower()
    if raw in _DEST_LABELS:
        return raw
    name = _event_text(payload.get('event'))
    if name.startswith('band_'):
        return 'band'
    if name.startswith('kakao_'):
        return 'kakao'
    if name.startswith('wa_') or name.startswith('whatsapp_'):
        return 'whatsapp'
    return ''


def _event_text(value):
    if isinstance(value, str):
        return value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ')
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return ''
    return str(value)


def jump_event_lines(events, fallback_domain=''):
    """Section 3: counts by source domain, then every raw body sorted by transaction_id."""
    counts = {}
    raw = []
    for row in events:
        body = row['body'] if isinstance(row['body'], str) else ''
        origin = row['origin'] if isinstance(row['origin'], str) else ''
        source = origin.strip() or fallback_domain
        transaction_id = ''
        try:
            payload = json.loads(body)
        except (TypeError, ValueError):
            payload = None
        if isinstance(payload, dict):
            transaction_id = _event_text(payload.get('transaction_id'))
            name = _event_text(payload.get('event'))
            kind = _JUMP_KINDS.get(name)
            if kind:
                key = (source, _jump_dest(payload), _event_text(payload.get('wa_env')), _event_text(payload.get('link_type')))
                bucket = counts.setdefault(key, {item: 0 for item in _JUMP_COLUMNS})
                bucket[kind] += 1
        raw.append((transaction_id, row['created'], source, body))
    lines = [
        '# 3 跳转事件（不受国家筛选，按来源域名 × 去向 × wa_env × link_type）',
        '域名\t去向\twa_env\tlink_type\t点击\t拉起\t兜底',
    ]
    for key in sorted(counts):
        bucket = counts[key]
        source, app, wa_env, link_type = key
        lines.append('\t'.join((source, _DEST_LABELS.get(app, app), wa_env, link_type, *(str(bucket[item]) for item in _JUMP_COLUMNS))))
    lines.extend([
        '',
        '# 3.1 全部原始 JSON（按 transaction_id 排序）',
        '收到时间\t来源域名\tJSON',
    ])
    raw.sort(key=lambda item: (item[0] == '', item[0], item[1]))
    for _transaction_id, created, source, body in raw:
        stamp = datetime.fromtimestamp(created, timezone(timedelta(hours=8))).isoformat(timespec='seconds')
        lines.append(f'{stamp}\t{source}\t{body}')
    return lines


def choose_split_member(members, mode):
    if mode == 'weighted':
        total = sum(item['weight'] for item in members)
        draw = secrets.randbelow(total)
        covered = 0
        for item in members:
            covered += item['weight']
            if draw < covered:
                return item
    return secrets.choice(members)


class Store:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.pages = self.directory / 'pages'
        self.pages.mkdir(exist_ok=True)
        self.path = self.directory / 'app.db'
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1), config TEXT NOT NULL, revision INTEGER NOT NULL, secret TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY, slot TEXT NOT NULL, name TEXT NOT NULL, created REAL NOT NULL, files INTEGER NOT NULL, bytes INTEGER NOT NULL, sha256 TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS slots(slot TEXT PRIMARY KEY, version_id TEXT REFERENCES versions(id));
                CREATE TABLE IF NOT EXISTS counters(ip_key TEXT PRIMARY KEY, started REAL NOT NULL, count INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS links(id INTEGER PRIMARY KEY, slot TEXT NOT NULL, url TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, UNIQUE(slot,url));
                CREATE TABLE IF NOT EXISTS rotation(slot TEXT PRIMARY KEY, last_id INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS redirect_presets(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL UNIQUE, note TEXT NOT NULL, created REAL NOT NULL, check_result TEXT);
                CREATE TABLE IF NOT EXISTS whatsapp_numbers(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT NOT NULL UNIQUE, note TEXT NOT NULL, created REAL NOT NULL, trust_result TEXT);
                CREATE TABLE IF NOT EXISTS contact_links(id INTEGER PRIMARY KEY AUTOINCREMENT, app TEXT NOT NULL, url TEXT NOT NULL, note TEXT NOT NULL, created REAL NOT NULL, UNIQUE(app, url));
                CREATE TABLE IF NOT EXISTS redirect_active(id INTEGER PRIMARY KEY CHECK(id=1), url TEXT NOT NULL, preset_id INTEGER REFERENCES redirect_presets(id) ON DELETE SET NULL, version_id TEXT NOT NULL REFERENCES versions(id), updated REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS redirect_split(id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL, mode TEXT NOT NULL, members TEXT NOT NULL, updated REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS redirect_split_assign(visitor_hash TEXT PRIMARY KEY, preset_id INTEGER, url TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS whatsapp_split(id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL, mode TEXT NOT NULL, members TEXT NOT NULL, updated REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS whatsapp_split_assign(visitor_hash TEXT PRIMARY KEY, number_id INTEGER, phone TEXT NOT NULL, display_name TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS whatsapp_trust_state(id INTEGER PRIMARY KEY CHECK(id=1), seen_trust INTEGER NOT NULL DEFAULT 0, seen_clear INTEGER NOT NULL DEFAULT 0, interval_seconds INTEGER NOT NULL DEFAULT 10);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, created REAL NOT NULL, ip TEXT NOT NULL, country TEXT, device TEXT NOT NULL, slot TEXT NOT NULL, reason TEXT NOT NULL, path TEXT NOT NULL, mode TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS events_created ON events(created);
                CREATE TABLE IF NOT EXISTS access_log(id INTEGER PRIMARY KEY, created REAL NOT NULL, ua TEXT NOT NULL, ch_ua TEXT NOT NULL, ch_platform TEXT NOT NULL, ch_platform_version TEXT NOT NULL, ch_mobile TEXT NOT NULL, referer TEXT NOT NULL, query TEXT NOT NULL, wa_number TEXT NOT NULL, cf_cache_status TEXT NOT NULL, country TEXT, city TEXT NOT NULL, status INTEGER NOT NULL, duration_ms INTEGER NOT NULL, path TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS access_log_created ON access_log(created);
                CREATE TABLE IF NOT EXISTS client_events(id INTEGER PRIMARY KEY, created REAL NOT NULL, body TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS client_events_created ON client_events(created);
                CREATE TABLE IF NOT EXISTS intake_log(id INTEGER PRIMARY KEY, created REAL NOT NULL, ip TEXT NOT NULL, ua TEXT NOT NULL, origin TEXT NOT NULL, referer TEXT NOT NULL, content_type TEXT NOT NULL, body_length INTEGER NOT NULL, body TEXT NOT NULL, status INTEGER NOT NULL, reason TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS intake_log_created ON intake_log(created);
                CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, created REAL NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL);
            ''')
            db.execute('BEGIN IMMEDIATE')
            columns = {row['name'] for row in db.execute('PRAGMA table_info(events)')}
            if 'device_details' not in columns:
                db.execute('ALTER TABLE events ADD COLUMN device_details TEXT')
            number_columns = {row['name'] for row in db.execute('PRAGMA table_info(whatsapp_numbers)')}
            if 'trust_result' not in number_columns:
                db.execute('ALTER TABLE whatsapp_numbers ADD COLUMN trust_result TEXT')
            if 'display_name' not in number_columns:
                db.execute("ALTER TABLE whatsapp_numbers ADD COLUMN display_name TEXT NOT NULL DEFAULT ''")
            trust_columns = {row['name'] for row in db.execute('PRAGMA table_info(whatsapp_trust_state)')}
            if 'interval_seconds' not in trust_columns:
                db.execute('ALTER TABLE whatsapp_trust_state ADD COLUMN interval_seconds INTEGER NOT NULL DEFAULT 10')
            event_columns = {row['name'] for row in db.execute('PRAGMA table_info(client_events)')}
            if 'origin' not in event_columns:
                db.execute("ALTER TABLE client_events ADD COLUMN origin TEXT NOT NULL DEFAULT ''")
            access_columns = {row['name'] for row in db.execute('PRAGMA table_info(access_log)')}
            if 'ip' not in access_columns:
                db.execute("ALTER TABLE access_log ADD COLUMN ip TEXT NOT NULL DEFAULT ''")
            # Kept rows are copies saved when a domain is deleted. The landing
            # process never writes these tables, so its retention pass cannot drop them.
            db.executescript('''
                CREATE TABLE IF NOT EXISTS kept_events(id INTEGER PRIMARY KEY, created REAL NOT NULL, ip TEXT NOT NULL, country TEXT, device TEXT NOT NULL, slot TEXT NOT NULL, reason TEXT NOT NULL, path TEXT NOT NULL, mode TEXT NOT NULL, device_details TEXT);
                CREATE INDEX IF NOT EXISTS kept_events_created ON kept_events(created);
                CREATE TABLE IF NOT EXISTS kept_access_log(id INTEGER PRIMARY KEY, created REAL NOT NULL, ua TEXT NOT NULL, ch_ua TEXT NOT NULL, ch_platform TEXT NOT NULL, ch_platform_version TEXT NOT NULL, ch_mobile TEXT NOT NULL, referer TEXT NOT NULL, query TEXT NOT NULL, wa_number TEXT NOT NULL, cf_cache_status TEXT NOT NULL, country TEXT, city TEXT NOT NULL, status INTEGER NOT NULL, duration_ms INTEGER NOT NULL, path TEXT NOT NULL, ip TEXT NOT NULL DEFAULT '');
                CREATE INDEX IF NOT EXISTS kept_access_created ON kept_access_log(created);
                CREATE TABLE IF NOT EXISTS kept_client_events(id INTEGER PRIMARY KEY, created REAL NOT NULL, body TEXT NOT NULL, origin TEXT NOT NULL DEFAULT '');
                CREATE INDEX IF NOT EXISTS kept_client_events_created ON kept_client_events(created);
                CREATE TABLE IF NOT EXISTS kept_intake_log(id INTEGER PRIMARY KEY, created REAL NOT NULL, ip TEXT NOT NULL, ua TEXT NOT NULL, origin TEXT NOT NULL, referer TEXT NOT NULL, content_type TEXT NOT NULL, body_length INTEGER NOT NULL, body TEXT NOT NULL, status INTEGER NOT NULL, reason TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS kept_intake_created ON kept_intake_log(created);
            ''')
            db.execute('INSERT OR IGNORE INTO settings VALUES(1,?,0,?)', (Config().model_dump_json(), secrets.token_hex(32)))
            db.executemany('INSERT OR IGNORE INTO slots(slot) VALUES(?)', [('A',), ('B',)])
            self.secret = db.execute('SELECT secret FROM settings WHERE id=1').fetchone()[0].encode()

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def config(self):
        with self.connect() as db:
            row = db.execute('SELECT config,revision FROM settings WHERE id=1').fetchone()
        return Config.model_validate_json(row['config']), row['revision']

    def _audit(self, db, action, detail):
        db.execute('INSERT INTO audit(created,action,detail) VALUES(?,?,?)', (time.time(), action, json.dumps(detail, ensure_ascii=False)))
        db.execute('DELETE FROM audit WHERE id <= (SELECT MAX(id)-2000 FROM audit)')

    def save_config(self, config, revision):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT config,revision FROM settings WHERE id=1').fetchone()
            if old['revision'] != revision:
                raise Conflict('配置已被其他窗口修改，请刷新后重试')
            db.execute('UPDATE settings SET config=?,revision=revision+1 WHERE id=1', (config.model_dump_json(),))
            self._audit(db, 'config_updated', {'before': json.loads(old['config']), 'after': config.model_dump()})

    def add_version(self, slot, version):
        with self.connect() as db:
            db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], slot, version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
            self._audit(db, 'content_imported', {'slot': slot, 'version': version['id'], 'files': version['files']})

    def versions(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT * FROM versions ORDER BY created DESC')]

    def version(self, version_id):
        with self.connect() as db:
            row = db.execute('SELECT * FROM versions WHERE id=?', (version_id,)).fetchone()
            return dict(row) if row else None

    def slots(self):
        with self.connect() as db:
            return {row['slot']: row['version_id'] for row in db.execute('SELECT * FROM slots')}

    def publish(self, slot, version_id):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            version = db.execute('SELECT id FROM versions WHERE id=? AND slot=?', (version_id, slot)).fetchone()
            if not version or not (self.pages / version_id / 'index.html').is_file():
                raise ValueError('版本不存在、槽位不符或入口文件缺失')
            old = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
            db.execute('UPDATE slots SET version_id=? WHERE slot=?', (version_id, slot))
            self._audit(db, 'version_published', {'slot': slot, 'before': old, 'after': version_id})

    def _version_directory(self, version_id):
        if not re.fullmatch(r'[a-f0-9]{32}', version_id or ''):
            raise ValueError('版本不存在或槽位不符')
        root = self.pages.resolve()
        target = (root / version_id).resolve()
        if target.parent != root:
            raise ValueError('版本不存在或槽位不符')
        return target

    def delete_version(self, version_id, slot='B'):
        """Hard-delete one unpublished A or B version and its files."""
        if slot not in ('A', 'B'):
            raise ValueError('只能删除未发布的 A 或 B 版本')
        target = self._version_directory(version_id)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            version = db.execute('SELECT id, slot, name FROM versions WHERE id=?', (version_id,)).fetchone()
            if not version or version['slot'] != slot:
                raise ValueError(f'只能删除未发布的 {slot} 版本')
            published = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
            if published == version_id:
                raise ValueError(f'不能删除当前发布的 {slot} 版本')
            active = db.execute('SELECT version_id FROM redirect_active WHERE id=1').fetchone()
            cleared_active = bool(active and active['version_id'] == version_id)
            if cleared_active:
                db.execute('DELETE FROM redirect_active WHERE id=1')
            if not db.execute('DELETE FROM versions WHERE id=? AND slot=?', (version_id, slot)).rowcount:
                raise ValueError(f'只能删除未发布的 {slot} 版本')
            self._audit(db, f'{slot.lower()}_version_deleted', {'version': version_id, 'slot': slot, 'name': version['name'], 'cleared_active': cleared_active})
        if target.exists():
            shutil.rmtree(target)
        return version_id

    def delete_unpublished_versions(self, slot):
        if slot not in ('A', 'B'):
            raise ValueError('只能删除未发布的 A 或 B 版本')
        with self.connect() as db:
            published = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
            ids = [row['id'] for row in db.execute('SELECT id FROM versions WHERE slot=? AND (? IS NULL OR id != ?) ORDER BY created', (slot, published, published))]
        deleted = []
        for version_id in ids:
            try:
                self.delete_version(version_id, slot)
            except ValueError:
                continue
            deleted.append(version_id)
        return deleted

    def delete_unpublished_b_versions(self):
        return self.delete_unpublished_versions('B')

    def save_source(self, slot, base, path, content, expected_published):
        version = edit_content(self.pages / base['id'], path, content, self.pages, base['name'])
        try:
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                current = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
                if current != expected_published:
                    raise Conflict('当前发布版本已改变，请重新加载后再保存')
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], slot, version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute('UPDATE slots SET version_id=? WHERE slot=?', (version['id'], slot))
                self._audit(db, 'content_imported', {'slot': slot, 'version': version['id'], 'files': version['files'], 'source_version': base['id'], 'path': path})
                self._audit(db, 'version_published', {'slot': slot, 'before': current, 'after': version['id']})
        except Exception:
            shutil.rmtree(self.pages / version['id'])
            raise
        return version | {'slot': slot}

    def count(self, ip, hours, increment, now=None):
        now = time.time() if now is None else now
        normalized = str(ipaddress.ip_address(ip))
        key = hmac.new(self.secret, normalized.encode(), hashlib.sha256).hexdigest()
        with self.connect() as db:
            if increment:
                db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT started,count FROM counters WHERE ip_key=?', (key,)).fetchone()
            active = row and now < row['started'] + hours * 3600
            count = row['count'] if active else 0
            if increment:
                count += 1
                started = row['started'] if active else now
                db.execute('INSERT INTO counters VALUES(?,?,?) ON CONFLICT(ip_key) DO UPDATE SET started=excluded.started,count=excluded.count', (key, started, count))
                db.execute('DELETE FROM counters WHERE started<?', (now - 720 * 3600,))
            return count

    @staticmethod
    def _redirect_preset(row):
        if row is None:
            raise KeyError('备用链接不存在')
        value = dict(row)
        value['check'] = json.loads(value.pop('check_result')) if row['check_result'] else {'status':'unchecked', 'platform':'网站', 'detail':'', 'checked_at':None, 'http_status':None, 'final_url':None}
        return value

    def redirect_presets(self):
        with self.connect() as db:
            return [self._redirect_preset(row) for row in db.execute('SELECT * FROM redirect_presets ORDER BY id')]

    def redirect_preset(self, preset_id):
        with self.connect() as db:
            return self._redirect_preset(db.execute('SELECT * FROM redirect_presets WHERE id=?', (preset_id,)).fetchone())

    def add_redirect_presets(self, urls, note):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing = {row['url'] for row in db.execute('SELECT url FROM redirect_presets')}
            if len(existing | set(urls)) > 100:
                raise ValueError('每个域名最多保存 100 条备用链接，请先删除不用的链接')
            db.executemany('INSERT OR IGNORE INTO redirect_presets(url,note,created) VALUES(?,?,?)', [(url, note, time.time()) for url in urls])
            self._audit(db, 'b_redirect_presets_added', {'count':len(urls)})
            return [self._redirect_preset(db.execute('SELECT * FROM redirect_presets WHERE url=?', (url,)).fetchone()) for url in urls]

    def delete_redirect_preset(self, preset_id):
        with self.connect() as db:
            if not db.execute('DELETE FROM redirect_presets WHERE id=?', (preset_id,)).rowcount:
                raise KeyError('备用链接不存在')
            self._audit(db, 'b_redirect_preset_deleted', {'id':preset_id})

    def save_redirect_check(self, preset, result, commit_guard=None):
        with self.connect() as db:
            if commit_guard:
                commit_guard(db)
            if not db.execute('UPDATE redirect_presets SET check_result=? WHERE id=? AND url=?', (json.dumps(result, ensure_ascii=False), preset['id'], preset['url'])).rowcount:
                raise KeyError('备用链接已删除或变更')
            return self._redirect_preset(db.execute('SELECT * FROM redirect_presets WHERE id=?', (preset['id'],)).fetchone())

    def redirect_active(self):
        with self.connect() as db:
            row = db.execute('SELECT url,preset_id,version_id,updated FROM redirect_active WHERE id=1').fetchone()
            return dict(row) if row else None

    def redirect_split(self):
        with self.connect() as db:
            row = db.execute('SELECT enabled,mode,members,updated FROM redirect_split WHERE id=1').fetchone()
            presets = {item['id']: item['url'] for item in db.execute('SELECT id,url FROM redirect_presets')}
        if not row:
            return {'enabled': False, 'mode': 'random', 'members': [], 'updated': None}
        members = []
        for item in json.loads(row['members']):
            url = presets.get(item['preset_id'])
            if url:
                members.append({'preset_id': item['preset_id'], 'weight': item['weight'], 'url': url})
        return {'enabled': bool(row['enabled']), 'mode': row['mode'], 'members': members, 'updated': row['updated']}

    def save_redirect_split(self, enabled, mode, members):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            found = {row['id'] for row in db.execute('SELECT id FROM redirect_presets')}
            if any(item.preset_id not in found for item in members):
                raise ValueError('分流链接不在预设池中，请刷新后再保存')
            if enabled and not members:
                raise ValueError('开启分流时至少选择一条预设链接')
            payload = json.dumps([{'preset_id': item.preset_id, 'weight': item.weight} for item in members], ensure_ascii=False)
            db.execute('''INSERT INTO redirect_split VALUES(1,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET enabled=excluded.enabled, mode=excluded.mode, members=excluded.members, updated=excluded.updated''',
                (int(enabled), mode, payload, time.time()))
            self._audit(db, 'b_redirect_split_updated', {'enabled': enabled, 'mode': mode, 'count': len(members)})
        return self.redirect_split()

    def split_destination(self, visitor_hash):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            split = db.execute('SELECT enabled,mode,members FROM redirect_split WHERE id=1').fetchone()
            if not split or not split['enabled']:
                return None
            existing = db.execute('SELECT url FROM redirect_split_assign WHERE visitor_hash=?', (visitor_hash,)).fetchone()
            if existing:
                return existing['url']
            chosen = []
            for item in json.loads(split['members']):
                preset = db.execute('SELECT id,url FROM redirect_presets WHERE id=?', (item['preset_id'],)).fetchone()
                if preset:
                    chosen.append({'preset_id': preset['id'], 'url': preset['url'], 'weight': item['weight']})
            if not chosen:
                return None
            pick = choose_split_member(chosen, split['mode'])
            db.execute('INSERT OR IGNORE INTO redirect_split_assign(visitor_hash,preset_id,url,created) VALUES(?,?,?,?)', (visitor_hash, pick['preset_id'], pick['url'], time.time()))
            return db.execute('SELECT url FROM redirect_split_assign WHERE visitor_hash=?', (visitor_hash,)).fetchone()['url']

    def apply_redirects(self, base, preset, occurrence_ids, expected_published, commit_guard=None):
        from .redirects import replace_bundle, rewrite_jump_bundle
        if base['slot'] != 'B':
            raise KeyError('B 版本不存在')
        span_version, span_changed = None, 0
        if occurrence_ids:
            span_version, span_changed = replace_bundle(self.pages / base['id'], base['id'], occurrence_ids, preset['url'], self.pages, base['name'])
        root_id = span_version['id'] if span_version else base['id']
        try:
            jump_version, jump_changed, reason = rewrite_jump_bundle(self.pages / root_id, base['name'], self.pages, preset['url'])
        except Exception:
            if span_version is not None:
                shutil.rmtree(self.pages / span_version['id'], ignore_errors=True)
            raise
        if not occurrence_ids and reason == 'no-function':
            raise ValueError('这一版没有 WhatsApp 跳转函数，没有改点击')
        if not occurrence_ids and reason == 'no-config':
            raise ValueError('当前 B 页没有 CONFIG，没有改点击')
        version = jump_version or span_version
        changed = (span_changed or 0) + (jump_changed or 0)
        interim_id = span_version['id'] if span_version and jump_version else None
        try:
            with self.connect() as db:
                if commit_guard:
                    commit_guard(db)
                else:
                    db.execute('BEGIN IMMEDIATE')
                current = db.execute("SELECT version_id FROM slots WHERE slot='B'").fetchone()[0]
                if current != expected_published:
                    raise Conflict('当前 B 发布版本已变化，请重新扫描后再换链')
                saved = db.execute('SELECT url FROM redirect_presets WHERE id=?', (preset['id'],)).fetchone()
                if not saved or saved['url'] != preset['url']:
                    raise KeyError('备用链接已删除或变更')
                if version is None:
                    db.execute('INSERT INTO redirect_active VALUES(1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET url=excluded.url,preset_id=excluded.preset_id,version_id=excluded.version_id,updated=excluded.updated', (preset['url'], preset['id'], base['id'], time.time()))
                    return base | {'slot':'B'}, 0
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], 'B', version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute("UPDATE slots SET version_id=? WHERE slot='B'", (version['id'],))
                db.execute('INSERT INTO redirect_active VALUES(1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET url=excluded.url,preset_id=excluded.preset_id,version_id=excluded.version_id,updated=excluded.updated', (preset['url'], preset['id'], version['id'], time.time()))
                self._audit(db, 'content_imported', {'slot':'B', 'version':version['id'], 'source_version':base['id'], 'files':version['files'], 'redirects_changed':changed, 'jump_url':preset['url']})
                self._audit(db, 'version_published', {'slot':'B', 'before':current, 'after':version['id']})
        except Exception:
            if version is not None:
                shutil.rmtree(self.pages / version['id'], ignore_errors=True)
            if interim_id:
                shutil.rmtree(self.pages / interim_id, ignore_errors=True)
            raise
        if interim_id:
            shutil.rmtree(self.pages / interim_id, ignore_errors=True)
        return version | {'slot':'B'}, changed

    @staticmethod
    def _trust_public(raw):
        blank = {'status':'unchecked', 'detail':'', 'checked_at':None}
        if not raw:
            return blank
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            return blank
        status = data.get('status')
        if status not in ('trust', 'clear', 'unconfirmed'):
            return blank
        detail = {'trust':'出现信任弹窗', 'clear':'正常', 'unconfirmed':'这次没看清' if data.get('reason') != 'unconfigured' else '云手机还没接上'}[status]
        return {'status':status, 'detail':detail, 'checked_at':data.get('checked_at')}

    @classmethod
    def _whatsapp_number(cls, row):
        if row is None:
            raise KeyError('WhatsApp 号码不存在')
        value = dict(row)
        value['trust'] = cls._trust_public(value.pop('trust_result', None))
        return value

    def whatsapp_numbers(self):
        with self.connect() as db:
            return [self._whatsapp_number(row) for row in db.execute('SELECT * FROM whatsapp_numbers ORDER BY id')]

    def whatsapp_number(self, number_id):
        with self.connect() as db:
            return self._whatsapp_number(db.execute('SELECT * FROM whatsapp_numbers WHERE id=?', (number_id,)).fetchone())

    def add_whatsapp_numbers(self, phones, note, display_name=''):
        if display_name and len(phones) != 1:
            raise ValueError('写接待名时一次只填一个号码')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing = {row['phone'] for row in db.execute('SELECT phone FROM whatsapp_numbers')}
            if len(existing | set(phones)) > 100:
                raise ValueError('每个域名最多保存 100 个 WhatsApp 号码，请先删除不用的号码')
            db.executemany('INSERT OR IGNORE INTO whatsapp_numbers(phone,note,created,display_name) VALUES(?,?,?,?)', [(phone, note, time.time(), display_name if len(phones) == 1 else '') for phone in phones])
            if display_name:
                db.execute('UPDATE whatsapp_numbers SET display_name=? WHERE phone=?', (display_name, phones[0]))
            self._audit(db, 'whatsapp_numbers_added', {'count':len(phones)})
            return [self._whatsapp_number(db.execute('SELECT * FROM whatsapp_numbers WHERE phone=?', (phone,)).fetchone()) for phone in phones]

    def upsert_whatsapp_name(self, phone, display_name):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT id FROM whatsapp_numbers WHERE phone=?', (phone,)).fetchone()
            if row:
                db.execute('UPDATE whatsapp_numbers SET display_name=? WHERE phone=?', (display_name, phone))
            else:
                if db.execute('SELECT COUNT(*) FROM whatsapp_numbers').fetchone()[0] >= 100:
                    raise ValueError('每个域名最多保存 100 个 WhatsApp 号码，请先删除不用的号码')
                db.execute('INSERT INTO whatsapp_numbers(phone,note,created,display_name) VALUES(?,?,?,?)', (phone, '', time.time(), display_name))
            self._audit(db, 'whatsapp_numbers_added', {'phone': phone})
            saved = self._whatsapp_number(db.execute('SELECT * FROM whatsapp_numbers WHERE phone=?', (phone,)).fetchone())
        return saved

    def delete_whatsapp_number(self, number_id):
        with self.connect() as db:
            if not db.execute('DELETE FROM whatsapp_numbers WHERE id=?', (number_id,)).rowcount:
                raise KeyError('WhatsApp 号码不存在')
            self._audit(db, 'whatsapp_number_deleted', {'id':number_id})

    def contact_links(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT id,app,url,note,created FROM contact_links ORDER BY id')]

    def contact_link(self, link_id):
        with self.connect() as db:
            row = db.execute('SELECT id,app,url,note,created FROM contact_links WHERE id=?', (link_id,)).fetchone()
        if not row:
            raise ValueError('这条链接不在预存里，请刷新后再换')
        return dict(row)

    def add_contact_links(self, app, urls, note):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing = {(row['app'], row['url']) for row in db.execute('SELECT app,url FROM contact_links')}
            if len(existing | {(app, url) for url in urls}) > 100:
                raise ValueError('每个域名最多保存 100 条 BAND / Kakao 链接，请先删除不用的')
            db.executemany('INSERT OR IGNORE INTO contact_links(app,url,note,created) VALUES(?,?,?,?)', [(app, url, note, time.time()) for url in urls])
            if note:
                db.executemany('UPDATE contact_links SET note=? WHERE app=? AND url=?', [(note, app, url) for url in urls])
            self._audit(db, 'contact_links_added', {'app': app, 'count': len(urls)})
            placeholders = ','.join('?' for _ in urls)
            return [dict(row) for row in db.execute(f'SELECT id,app,url,note,created FROM contact_links WHERE app=? AND url IN ({placeholders}) ORDER BY id', (app, *urls))]

    def delete_contact_link(self, link_id):
        with self.connect() as db:
            if not db.execute('DELETE FROM contact_links WHERE id=?', (link_id,)).rowcount:
                raise ValueError('这条链接不在预存里')
            self._audit(db, 'contact_link_deleted', {'id': link_id})

    def save_whatsapp_trust(self, number_id, status, reason):
        if status not in ('trust', 'clear', 'unconfirmed'):
            raise ValueError('信任检测结果无效')
        payload = json.dumps({'status':status, 'reason':reason or '', 'checked_at':time.time()}, ensure_ascii=False)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not db.execute('UPDATE whatsapp_numbers SET trust_result=? WHERE id=?', (payload, number_id)).rowcount:
                raise KeyError('WhatsApp 号码不存在')
            # Once both a trust popup and a clear screen have ever been seen, polling
            # stays on. Otherwise an auto-switch that leaves no number currently
            # 'clear' would turn polling off and stop watching the new number.
            if status in ('trust', 'clear'):
                column = 'seen_trust' if status == 'trust' else 'seen_clear'
                db.execute(f'INSERT INTO whatsapp_trust_state(id,{column}) VALUES(1,1) '
                           f'ON CONFLICT(id) DO UPDATE SET {column}=1')
            self._audit(db, 'whatsapp_trust_checked', {'id':number_id, 'status':status})
        return self.whatsapp_number(number_id)

    def whatsapp_trust_poll_enabled(self):
        with self.connect() as db:
            state = db.execute('SELECT seen_trust,seen_clear FROM whatsapp_trust_state WHERE id=1').fetchone()
            if state and state['seen_trust'] and state['seen_clear']:
                return True
            found = set()
            for row in db.execute('SELECT trust_result FROM whatsapp_numbers'):
                if not row['trust_result']:
                    continue
                try:
                    found.add(json.loads(row['trust_result']).get('status'))
                except (TypeError, ValueError):
                    continue
            return 'trust' in found and 'clear' in found

    def trust_interval(self):
        with self.connect() as db:
            row = db.execute('SELECT interval_seconds FROM whatsapp_trust_state WHERE id=1').fetchone()
        if not row or not row['interval_seconds']:
            return 10
        return max(10, min(86400, int(row['interval_seconds'])))

    def set_trust_interval(self, seconds):
        seconds = int(seconds)
        if seconds < 10 or seconds > 86400:
            raise ValueError('复查间隔要在 10 到 86400 秒之间')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO whatsapp_trust_state(id,seen_trust,seen_clear,interval_seconds) VALUES(1,0,0,?) '
                       'ON CONFLICT(id) DO UPDATE SET interval_seconds=excluded.interval_seconds', (seconds,))
        return seconds

    def published_whatsapp_phones(self):
        from .redirects import scan_bundle
        version_id = self.slots().get('B') or ''
        if not version_id or not (self.pages / version_id).is_dir():
            return []
        try:
            occurrences, _warnings = scan_bundle(self.pages / version_id, version_id)
        except (OSError, ValueError):
            return []
        phones = []
        for item in occurrences:
            phone = item.get('url') if item.get('kind') == 'whatsapp_number' else ''
            if phone and phone not in phones:
                phones.append(phone)
        return phones

    def relieve_trusted_number(self, phone):
        """Publish the next spare when this phone is the live number and shows a trust popup.

        A group-link jump stays. Manual number replacement still clears that jump.
        """
        numbers = self.whatsapp_numbers()
        current = next((item for item in numbers if item['phone'] == phone), None)
        if not current or current['trust']['status'] != 'trust':
            return {'switched': False, 'alarm': False}
        version_id = self.slots().get('B') or ''
        base = self.version(version_id) if version_id else None
        if not base:
            return {'switched': False, 'alarm': False}
        from .redirects import scan_bundle
        occurrences, _warnings = scan_bundle(self.pages / version_id, version_id)
        targets = [item['id'] for item in occurrences if item.get('kind') == 'whatsapp_number' and item.get('url') == phone]
        if not targets:
            return {'switched': False, 'alarm': False}
        start = next(index for index, item in enumerate(numbers) if item['phone'] == phone)
        nxt = None
        for step in range(1, len(numbers)):
            candidate = numbers[(start + step) % len(numbers)]
            if candidate['phone'] != phone and candidate['trust']['status'] != 'trust':
                nxt = candidate
                break
        if nxt is None:
            return {'switched': False, 'alarm': True}
        _version, changed = self.apply_whatsapp_number(base, nxt, targets, version_id, keep_jump=True, automatic=True)
        return {'switched': bool(changed), 'alarm': not changed, 'changed': changed or 0}

    def _reception_bundle(self, root_id, name, filename, required=False):
        from .archives import MAX_TOTAL, read_source, source_files, validate_file, write_bundle
        from .redirects import rewrite_reception_bytes
        files, total, edited, digest, changed, found = source_files(self.pages / root_id), 0, [], hashlib.sha256(), False, False
        for path, (file, _) in sorted(files.items()):
            data = read_source(file, path)
            rewritten = rewrite_reception_bytes(data, name)
            if rewritten != data:
                changed = True
            try:
                text = rewritten.decode('utf-8-sig')
            except UnicodeError:
                text = ''
            if 'reception-text' in text or '本次由助理' in text:
                found = True
            validate_file(path, rewritten)
            total += len(rewritten)
            if total > MAX_TOTAL:
                raise ValueError('源码目录超过总大小限制')
            edited.append((path, rewritten))
            digest.update(path.encode() + b'\0' + str(len(rewritten)).encode() + b'\0' + rewritten)
        if required and not found:
            raise ValueError('当前 B 页没有「本次由助理…接待」')
        if not changed:
            return None, 0
        return write_bundle(edited, filename, self.pages, digest.hexdigest()), 1

    def publish_reception(self, base, name, expected_published, commit_guard=None):
        if base['slot'] != 'B':
            raise KeyError('B 版本不存在')
        version, changed = self._reception_bundle(base['id'], name, base['name'], required=True)
        return self._commit_b_version(base, version, changed, expected_published, commit_guard, {'slot':'B', 'version': version['id'] if version else base['id'], 'reception': name, 'redirects_changed': changed})

    def publish_direct_entry(self, base, expected_published, commit_guard=None):
        """Publish the current B page with the popup skipped."""
        from .archives import MAX_TOTAL, read_source, source_files, validate_file, write_bundle
        from .redirects import next_direct_mode, read_direct_mode, set_direct_mode, strip_lead_gate
        if base['slot'] != 'B':
            raise KeyError('B 版本不存在')
        files = source_files(self.pages / base['id'])
        decoded = []
        saw_direct = False
        index_mode = None
        fallback_mode = None
        for path, (file, _) in sorted(files.items()):
            data = read_source(file, path)
            bom, text = False, None
            if Path(path).suffix.lower() in ('.html', '.htm'):
                bom = data.startswith(b'\xef\xbb\xbf')
                raw = data[3:] if bom else data
                try:
                    text = raw.decode('utf-8')
                except UnicodeError:
                    text = None
                mode = read_direct_mode(text) if text is not None else None
                if mode:
                    saw_direct = True
                    if Path(path).name.lower() in ('index.html', 'index.htm') and index_mode is None:
                        index_mode = mode
                    elif fallback_mode is None:
                        fallback_mode = mode
            decoded.append((path, data, bom, text))
        if saw_direct:
            target = next_direct_mode(index_mode or fallback_mode)
            total, edited, digest = 0, [], hashlib.sha256()
            changed_any = False
            for path, data, bom, text in decoded:
                if text is not None and read_direct_mode(text):
                    rewritten = set_direct_mode(text, target)
                    if rewritten != text:
                        changed_any = True
                        payload = rewritten.encode('utf-8')
                        data = (b'\xef\xbb\xbf' + payload) if bom else payload
                validate_file(path, data)
                total += len(data)
                if total > MAX_TOTAL:
                    raise ValueError('源码目录超过总大小限制')
                edited.append((path, data))
                digest.update(path.encode() + b'\0' + str(len(data)).encode() + b'\0' + data)
            if not changed_any:
                raise ValueError('开关没有变化，没有改动')
            version = write_bundle(edited, base['name'], self.pages, digest.hexdigest())
            committed, changed = self._commit_b_version(base, version, 1, expected_published, commit_guard, {'slot':'B', 'version': version['id'], 'direct_entry': True, 'redirects_changed': 1})
            return committed, changed, target.lower()
        total, edited, digest = 0, [], hashlib.sha256()
        saw_gate, saw_pool = False, False
        for path, data, bom, text in decoded:
            if text is not None:
                has_gate = bool(re.search(r'\bid\s*=\s*(["\'])lead-gate\1', text))
                if has_gate:
                    saw_gate = True
                    rewritten = strip_lead_gate(text)
                    payload = rewritten.encode('utf-8')
                    data = (b'\xef\xbb\xbf' + payload) if bom else payload
                elif 'RANDOM_POOL' in text:
                    saw_pool = True
            validate_file(path, data)
            total += len(data)
            if total > MAX_TOTAL:
                raise ValueError('源码目录超过总大小限制')
            edited.append((path, data))
            digest.update(path.encode() + b'\0' + str(len(data)).encode() + b'\0' + data)
        if not saw_gate:
            if saw_pool:
                raise ValueError('两步问卷已经拿掉，进线语已经是随机的。')
            raise ValueError('当前 B 页没有两步问卷')
        version = write_bundle(edited, base['name'], self.pages, digest.hexdigest())
        committed, changed = self._commit_b_version(base, version, 1, expected_published, commit_guard, {'slot':'B', 'version': version['id'], 'direct_entry': True, 'redirects_changed': 1})
        return committed, changed, 'gate'

    def published_direct_mode(self):
        """ABC, ABCABC, CBA, or None for the B page visitors are being served."""
        from .redirects import read_direct_mode
        version_id = self.slots()['B']
        if not version_id:
            return None
        root = self.pages / version_id
        if not root.is_dir():
            return None
        index_mode = None
        fallback = None
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in ('.html', '.htm'):
                continue
            try:
                data = path.read_bytes()
                if data.startswith(b'\xef\xbb\xbf'):
                    data = data[3:]
                mode = read_direct_mode(data.decode('utf-8'))
            except (OSError, UnicodeError, ValueError):
                continue
            if not mode:
                continue
            if path.name.lower() in ('index.html', 'index.htm') and index_mode is None:
                index_mode = mode
            elif fallback is None:
                fallback = mode
        return index_mode or fallback

    def apply_whatsapp_number(self, base, number, occurrence_ids, expected_published, commit_guard=None, *, keep_jump=False, automatic=False):
        from .redirects import replace_bundle, rewrite_jump_bundle
        if base['slot'] != 'B':
            raise KeyError('B 版本不存在')
        version, changed = replace_bundle(self.pages / base['id'], base['id'], occurrence_ids, number['phone'], self.pages, base['name'])
        scratch = [version['id']] if version else []
        try:
            if number.get('display_name'):
                root_id = version['id'] if version else base['id']
                reception, reception_changed = self._reception_bundle(root_id, number['display_name'], base['name'])
                if reception:
                    scratch.append(reception['id'])
                    version = reception
                    changed = (changed or 0) + reception_changed
            # Manual replacement clears a group-link jump so the click returns to the number.
            # Automatic relief only replaces the burned phone, so a link the operator chose stays.
            if not keep_jump:
                root_id = version['id'] if version else base['id']
                cleared, clear_changed, _reason = rewrite_jump_bundle(self.pages / root_id, base['name'], self.pages, '')
                if cleared:
                    scratch.append(cleared['id'])
                    version = cleared
                    changed = (changed or 0) + clear_changed
        except Exception:
            for item in scratch:
                shutil.rmtree(self.pages / item, ignore_errors=True)
            raise
        try:
            with self.connect() as db:
                if commit_guard:
                    commit_guard(db)
                else:
                    db.execute('BEGIN IMMEDIATE')
                current = db.execute("SELECT version_id FROM slots WHERE slot='B'").fetchone()[0]
                if current != expected_published:
                    raise Conflict('当前 B 发布版本已变化，请重新扫描后再换号')
                saved = db.execute('SELECT phone FROM whatsapp_numbers WHERE id=?', (number['id'],)).fetchone()
                if not saved or saved['phone'] != number['phone']:
                    raise KeyError('WhatsApp 号码已删除或变更')
                if version is None:
                    return base | {'slot':'B'}, 0
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], 'B', version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute("UPDATE slots SET version_id=? WHERE slot='B'", (version['id'],))
                if not keep_jump:
                    db.execute('DELETE FROM redirect_active WHERE id=1')
                detail = {'slot':'B', 'version':version['id'], 'source_version':base['id'], 'files':version['files'], 'redirects_changed':changed, 'whatsapp_number':number['phone'], 'reception': number.get('display_name') or ''}
                if automatic:
                    detail['automatic'] = True
                self._audit(db, 'content_imported', detail)
                self._audit(db, 'version_published', {'slot':'B', 'before':current, 'after':version['id']})
        except Exception:
            for item in scratch:
                shutil.rmtree(self.pages / item, ignore_errors=True)
            raise
        for item in scratch:
            if version is None or item != version['id']:
                shutil.rmtree(self.pages / item, ignore_errors=True)
        return version | {'slot':'B'}, changed

    def apply_contact_link(self, base, link, expected_published, commit_guard=None):
        from .contact_config import rewrite_contact_bundle
        if base['slot'] != 'B':
            raise KeyError('B 版本不存在')
        version, changed, summary = rewrite_contact_bundle(self.pages / base['id'], base['name'], self.pages, link['app'], link['url'])
        try:
            with self.connect() as db:
                if commit_guard:
                    commit_guard(db)
                else:
                    db.execute('BEGIN IMMEDIATE')
                current = db.execute("SELECT version_id FROM slots WHERE slot='B'").fetchone()[0]
                if current != expected_published:
                    raise Conflict('当前 B 发布版本已变化，请重新扫描后再换')
                saved = db.execute('SELECT app,url FROM contact_links WHERE id=?', (link['id'],)).fetchone()
                if not saved or saved['app'] != link['app'] or saved['url'] != link['url']:
                    raise ValueError('这条链接已删除或变更，请刷新后再换')
                if version is None:
                    return base | {'slot':'B'}, 0, summary
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], 'B', version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute("UPDATE slots SET version_id=? WHERE slot='B'", (version['id'],))
                self._audit(db, 'content_imported', {'slot':'B', 'version':version['id'], 'source_version':base['id'], 'files':version['files'], 'redirects_changed':changed, 'contact_app':link['app'], 'contact_field':summary['contact_app'], 'url_field':summary['url']})
                self._audit(db, 'version_published', {'slot':'B', 'before':current, 'after':version['id']})
        except Exception:
            if version is not None:
                shutil.rmtree(self.pages / version['id'], ignore_errors=True)
            raise
        return version | {'slot':'B'}, changed, summary

    def _commit_b_version(self, base, version, changed, expected_published, commit_guard, detail):
        try:
            with self.connect() as db:
                if commit_guard:
                    commit_guard(db)
                else:
                    db.execute('BEGIN IMMEDIATE')
                current = db.execute("SELECT version_id FROM slots WHERE slot='B'").fetchone()[0]
                if current != expected_published:
                    raise Conflict('当前 B 发布版本已变化，请重新扫描后再换号')
                if version is None:
                    return base | {'slot':'B'}, 0
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], 'B', version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute("UPDATE slots SET version_id=? WHERE slot='B'", (version['id'],))
                self._audit(db, 'content_imported', detail | {'source_version': base['id'], 'files': version['files']})
                self._audit(db, 'version_published', {'slot':'B', 'before':current, 'after':version['id']})
        except Exception:
            if version is not None:
                shutil.rmtree(self.pages / version['id'], ignore_errors=True)
            raise
        return version | {'slot':'B'}, changed

    def whatsapp_split(self):
        with self.connect() as db:
            row = db.execute('SELECT enabled,mode,members,updated FROM whatsapp_split WHERE id=1').fetchone()
            numbers = {item['id']: item for item in db.execute('SELECT id,phone,display_name FROM whatsapp_numbers')}
        if not row:
            return {'enabled': False, 'mode': 'random', 'members': [], 'updated': None}
        members = []
        for item in json.loads(row['members']):
            number = numbers.get(item['number_id'])
            if number and number['display_name']:
                members.append({'number_id': number['id'], 'weight': item['weight'], 'phone': number['phone'], 'display_name': number['display_name']})
        return {'enabled': bool(row['enabled']), 'mode': row['mode'], 'members': members, 'updated': row['updated']}

    def save_whatsapp_split(self, enabled, mode, members):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            found = {row['id']: row['display_name'] for row in db.execute('SELECT id,display_name FROM whatsapp_numbers')}
            if any(item.number_id not in found for item in members):
                raise ValueError('分流号码不在号码池中，请刷新后再保存')
            if any(not found[item.number_id] for item in members):
                raise ValueError('参与分流的号码要先写接待名')
            if enabled and not members:
                raise ValueError('开启号码分流时至少选择一个号码')
            payload = json.dumps([{'number_id': item.number_id, 'weight': item.weight} for item in members], ensure_ascii=False)
            db.execute('''INSERT INTO whatsapp_split VALUES(1,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET enabled=excluded.enabled, mode=excluded.mode, members=excluded.members, updated=excluded.updated''',
                (int(enabled), mode, payload, time.time()))
            self._audit(db, 'whatsapp_split_updated', {'enabled': enabled, 'mode': mode, 'count': len(members)})
        return self.whatsapp_split()

    def whatsapp_split_destination(self, visitor_hash):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            split = db.execute('SELECT enabled,mode,members FROM whatsapp_split WHERE id=1').fetchone()
            if not split or not split['enabled']:
                return None
            existing = db.execute('SELECT number_id,phone,display_name FROM whatsapp_split_assign WHERE visitor_hash=?', (visitor_hash,)).fetchone()
            if existing:
                current = db.execute('SELECT phone,display_name FROM whatsapp_numbers WHERE id=?', (existing['number_id'],)).fetchone()
                if current and current['display_name']:
                    return {'number_id': existing['number_id'], 'phone': current['phone'], 'display_name': current['display_name']}
                # The number was deleted or lost its reception name: drop this stale
                # assignment and pick a fresh one so a retired number leaves rotation.
                db.execute('DELETE FROM whatsapp_split_assign WHERE visitor_hash=?', (visitor_hash,))
            chosen = []
            for item in json.loads(split['members']):
                number = db.execute('SELECT id,phone,display_name FROM whatsapp_numbers WHERE id=?', (item['number_id'],)).fetchone()
                if number and number['display_name']:
                    chosen.append({'number_id': number['id'], 'phone': number['phone'], 'display_name': number['display_name'], 'weight': item['weight']})
            if not chosen:
                return None
            pick = choose_split_member(chosen, split['mode'])
            db.execute('INSERT OR REPLACE INTO whatsapp_split_assign(visitor_hash,number_id,phone,display_name,created) VALUES(?,?,?,?,?)', (visitor_hash, pick['number_id'], pick['phone'], pick['display_name'], time.time()))
            saved = db.execute('SELECT number_id,phone,display_name FROM whatsapp_split_assign WHERE visitor_hash=?', (visitor_hash,)).fetchone()
            return {'number_id': saved['number_id'], 'phone': saved['phone'], 'display_name': saved['display_name']}

    def published_tracking(self):
        from .archives import read_source, source_files
        from .tracking import read_pages
        found = {}
        slots = self.slots()
        for slot in ('A', 'B'):
            version_id = slots.get(slot)
            info = {'version_id': version_id, 'ga4': '', 'conversion': '', 'ga4_body': '', 'conversion_body': ''}
            if version_id:
                try:
                    files = source_files(self.pages / version_id)
                    pairs = [(name, read_source(path, name)) for name, (path, _) in files.items()]
                    info.update(read_pages(pairs))
                except ValueError:
                    pass
            found[slot] = info
        return found

    def apply_tracking(self, slot, ga4_body, conversion_body, expected_published):
        from .archives import MAX_TOTAL, read_source, source_files, validate_file, write_bundle
        from .tracking import rewrite_pages
        if slot not in ('A', 'B'):
            raise ValueError('只能写入 A 或 B')
        if not ga4_body and not conversion_body:
            raise ValueError('请选择要写入的 GA4 或转化代码')
        published = self.slots().get(slot)
        if not published:
            raise ValueError('这个位置还没有发布页面')
        if expected_published and expected_published != published:
            raise Conflict('当前发布版本已变化，请刷新后再写入')
        base = self.version(published)
        if not base or base['slot'] != slot:
            raise ValueError('版本不存在或槽位不符')
        files = source_files(self.pages / published)
        pairs = [(name, read_source(path, name)) for name, (path, _) in sorted(files.items())]
        edited, changed = rewrite_pages(pairs, ga4_body, conversion_body)
        if not changed:
            raise ValueError('页面里的代码已经是这一份')
        total, digest = 0, hashlib.sha256()
        checked = []
        for name, data in edited:
            validate_file(name, data)
            total += len(data)
            if total > MAX_TOTAL:
                raise ValueError('源码目录超过总大小限制')
            checked.append((name, data))
            digest.update(name.encode('utf-8') + b'\x00' + str(len(data)).encode() + b'\x00' + data)
        version = write_bundle(checked, base['name'], self.pages, digest.hexdigest())
        try:
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                current = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
                if current != published:
                    raise Conflict('当前发布版本已变化，请刷新后再写入')
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], slot, version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute('UPDATE slots SET version_id=? WHERE slot=?', (version['id'], slot))
                self._audit(db, 'content_imported', {'slot': slot, 'version': version['id'], 'source_version': published, 'files': version['files'], 'tracking': True})
                self._audit(db, 'version_published', {'slot': slot, 'before': current, 'after': version['id']})
        except Exception:
            shutil.rmtree(self.pages / version['id'], ignore_errors=True)
            raise
        return version | {'slot': slot}

    def published_titles(self):
        from .archives import read_source, source_files
        from .page_title import choose_html, read_document_title
        found = {}
        slots = self.slots()
        for slot in ('A', 'B'):
            version_id = slots.get(slot) or ''
            info = {'version_id': version_id, 'title': '', 'file': ''}
            if version_id:
                try:
                    files = source_files(self.pages / version_id)
                    name = choose_html(files)
                    if name:
                        payload = read_source(files[name][0], name)
                        info['file'] = name
                        info['title'] = read_document_title(payload.decode('utf-8-sig'))
                except (ValueError, UnicodeDecodeError):
                    pass
            found[slot] = info
        return found

    def apply_page_title(self, slot, title, expected_published):
        from .archives import MAX_TOTAL, read_source, source_files, validate_file, write_bundle
        from .page_title import normalize_title, rewrite_title
        if slot not in ('A', 'B'):
            raise ValueError('只能改 A 或 B 的网站标题')
        title = normalize_title(title)
        published = self.slots().get(slot)
        if not published:
            raise ValueError('这个位置还没有发布页面')
        if expected_published and expected_published != published:
            raise Conflict('当前发布版本已变化，请刷新后再改标题')
        base = self.version(published)
        if not base or base['slot'] != slot:
            raise ValueError('版本不存在或槽位不符')
        files = source_files(self.pages / published)
        pairs = [(name, read_source(path, name)) for name, (path, _) in sorted(files.items())]
        edited, changed, chosen = rewrite_title(pairs, title)
        if not changed:
            raise ValueError('网站标题已经是这个')
        total, digest = 0, hashlib.sha256()
        checked = []
        for name, data in edited:
            validate_file(name, data)
            total += len(data)
            if total > MAX_TOTAL:
                raise ValueError('源码目录超过总大小限制')
            checked.append((name, data))
            digest.update(name.encode('utf-8') + b'\x00' + str(len(data)).encode() + b'\x00' + data)
        version = write_bundle(checked, base['name'], self.pages, digest.hexdigest())
        try:
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                current = db.execute('SELECT version_id FROM slots WHERE slot=?', (slot,)).fetchone()[0]
                if current != published:
                    raise Conflict('当前发布版本已变化，请刷新后再改标题')
                db.execute('INSERT INTO versions VALUES(?,?,?,?,?,?,?)', (version['id'], slot, version['name'], version['created'], version['files'], version['bytes'], version['sha256']))
                db.execute('UPDATE slots SET version_id=? WHERE slot=?', (version['id'], slot))
                self._audit(db, 'content_imported', {'slot': slot, 'version': version['id'], 'source_version': published, 'files': version['files'], 'page_title': chosen})
                self._audit(db, 'version_published', {'slot': slot, 'before': current, 'after': version['id']})
        except Exception:
            shutil.rmtree(self.pages / version['id'], ignore_errors=True)
            raise
        return version | {'slot': slot}, title

    def reset_counts(self):
        with self.connect() as db:
            db.execute('DELETE FROM counters')
            self._audit(db, 'counters_reset', {'scope': 'all IP visit counters; link allocation counts unchanged'})

    def clear_logs(self):
        with self.connect() as db:
            deleted = db.execute('DELETE FROM events').rowcount
            self._audit(db, 'logs_cleared', {'deleted': deleted})
        return deleted

    def clear_analysis(self):
        """Delete this site's deep-analysis rows: Hong Kong request log and landing-page events."""
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            access = db.execute('DELETE FROM access_log').rowcount
            events = db.execute('DELETE FROM client_events').rowcount
            intake = db.execute('DELETE FROM intake_log').rowcount
            self._audit(db, 'analysis_cleared', {'access': access, 'events': events, 'intake': intake})
        return {'access': access, 'events': events, 'intake': intake}

    def clear_logs_unless(self, keep):
        """Delete visit rows in this site only. keep(ip, country) uses the same display rule as the log list."""
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows = db.execute('SELECT id, ip, country FROM events').fetchall()
            remove = [row['id'] for row in rows if not keep(row['ip'], row['country'])]
            deleted = 0
            for start in range(0, len(remove), 500):
                chunk = remove[start:start + 500]
                deleted += db.execute(f"DELETE FROM events WHERE id IN ({','.join('?' * len(chunk))})", chunk).rowcount
            self._audit(db, 'logs_foreign_cleared', {'deleted': deleted, 'kept': len(rows) - deleted})
        return {'deleted': deleted, 'kept': len(rows) - deleted}

    def add_links(self, slot, urls):
        with self.connect() as db:
            db.executemany('INSERT OR IGNORE INTO links(slot,url) VALUES(?,?)', [(slot, url) for url in urls])
            self._audit(db, 'links_added', {'slot': slot, 'count': len(urls)})

    def delete_link(self, link_id):
        with self.connect() as db:
            if not db.execute('DELETE FROM links WHERE id=?', (link_id,)).rowcount:
                raise ValueError('链接不存在')
            self._audit(db, 'link_deleted', {'id': link_id})

    def links(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT * FROM links ORDER BY id')]

    def choose_link(self, slot, strategy, consume=True):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows = db.execute('SELECT * FROM links WHERE slot=? ORDER BY id', (slot,)).fetchall()
            if not rows:
                return None
            if strategy == 'random':
                row = secrets.choice(rows)
            elif strategy == 'equal':
                row = min(rows, key=lambda item: (item['hits'], item['id']))
            else:
                cursor = db.execute('SELECT last_id FROM rotation WHERE slot=?', (slot,)).fetchone()
                last = cursor[0] if cursor else 0
                row = next((item for item in rows if item['id'] > last), rows[0])
            if consume:
                db.execute('UPDATE links SET hits=hits+1 WHERE id=?', (row['id'],))
                db.execute('INSERT INTO rotation VALUES(?,?) ON CONFLICT(slot) DO UPDATE SET last_id=excluded.last_id', (slot, row['id']))
            return dict(row)

    def event(self, ip, country, decision, path, mode):
        exact = str(ipaddress.ip_address(ip))
        with self.connect() as db:
            details = decision.get('device_details')
            db.execute('INSERT INTO events(created,ip,country,device,slot,reason,path,mode,device_details) VALUES(?,?,?,?,?,?,?,?,?)', (time.time(), exact, country, decision['device'], decision['slot'], decision['reason'], path[:512], mode, json.dumps(details, ensure_ascii=False) if details else None))
            db.execute('DELETE FROM events WHERE created<? OR id <= (SELECT MAX(id)-10000 FROM events)', (time.time() - 30 * 86400,))

    def _reading(self, db, table, only_kept):
        """Live rows, or live rows plus copies kept from a deleted domain."""
        kept = 'kept_' + table
        has_kept = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (kept,)).fetchone()
        if only_kept:
            if not has_kept:
                return None
            names = [row['name'] for row in db.execute(f'PRAGMA table_info({kept})')]
            listed = ','.join(names)
            return f'(SELECT {listed} FROM {kept})'
        if not has_kept:
            return table
        shared = [row['name'] for row in db.execute(f'PRAGMA table_info({table})')]
        kept_names = {row['name'] for row in db.execute(f'PRAGMA table_info({kept})')}
        shared = [name for name in shared if name in kept_names]
        listed = ','.join(shared)
        return f'(SELECT {listed} FROM {table} UNION ALL SELECT {listed} FROM {kept})'

    def recent_count(self, seconds=60, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'events', only_kept)
            if relation is None:
                return 0
            return db.execute(f'SELECT COUNT(*) FROM {relation} WHERE created>=?', (time.time() - seconds,)).fetchone()[0]

    def logs(self, days=7, slot='', page=1, page_size=25, only_kept=False):
        where = 'created>=?'
        args = [time.time() - days * 86400]
        if slot:
            where += ' AND slot=?'
            args.append(slot)
        with self.connect() as db:
            relation = self._reading(db, 'events', only_kept)
            if relation is None:
                return {'items': [], 'total': 0, 'page': page, 'pages': 1}
            total = db.execute(f'SELECT COUNT(*) FROM {relation} WHERE {where}', args).fetchone()[0]
            order = 'created DESC, id DESC' if only_kept or relation != 'events' else 'id DESC'
            rows = db.execute(f'SELECT * FROM {relation} WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?', args + [page_size, (page - 1) * page_size]).fetchall()
            items = [dict(row) for row in rows]
            for item in items:
                item['device_details'] = json.loads(item['device_details']) if item.get('device_details') else None
            return {'items': items, 'total': total, 'page': page, 'pages': max(1, (total + page_size - 1) // page_size)}

    def stats(self, only_kept=False):
        midnight = datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        with self.connect() as db:
            relation = self._reading(db, 'events', only_kept)
            if relation is None:
                return {'total': 0, 'allowed': 0, 'blocked': 0, 'today': 0}
            row = db.execute(f"SELECT COUNT(*) total,COALESCE(SUM(slot='B'),0) allowed,COALESCE(SUM(slot='A'),0) blocked,COALESCE(SUM(created>=?),0) today FROM {relation} WHERE created>=?", (midnight, time.time() - 30 * 86400)).fetchone()
            return dict(row)

    def audit(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100')]

    def record_access(self, ua, ch_ua, ch_platform, ch_platform_version, ch_mobile, referer, query, wa_number, cf_cache_status, country, city, status, duration_ms, path, ip=''):
        """One row per visitor request. A failure here must not break the page."""
        with self.connect() as db:
            db.execute('''INSERT INTO access_log(created,ua,ch_ua,ch_platform,ch_platform_version,ch_mobile,referer,query,wa_number,cf_cache_status,country,city,status,duration_ms,path,ip)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
                time.time(), ua, ch_ua, ch_platform, ch_platform_version, ch_mobile, referer, query, wa_number, cf_cache_status, country, city, status, duration_ms, path, (ip or '')[:80]))
            latest = db.execute('SELECT MAX(id) FROM access_log').fetchone()[0]
            if latest and latest % 200 == 0:
                db.execute('DELETE FROM access_log WHERE created<?', (time.time() - 90 * 86400,))

    def record_client_event(self, body, origin=''):
        if not isinstance(origin, str):
            origin = ''
        with self.connect() as db:
            db.execute('INSERT INTO client_events(created,body,origin) VALUES(?,?,?)', (time.time(), body, origin.strip()[:253]))
            latest = db.execute('SELECT MAX(id) FROM client_events').fetchone()[0]
            if latest and latest % 200 == 0:
                db.execute('DELETE FROM client_events WHERE created<?', (time.time() - 90 * 86400,))

    def access_report(self, days=7, country=None, domain='', rename_from='', only_kept=False):
        """Plain-text weekly export. Days are Hong Kong dates. Counts are requests."""
        since = time.time() - days * 86400
        where, args = 'created>=?', [since]
        if country:
            where += ' AND country=?'
            args.append(country)
        with self.connect() as db:
            access = self._reading(db, 'access_log', only_kept)
            clients = self._reading(db, 'client_events', only_kept)
            if access is None or clients is None:
                ua_rows, cross, events = [], [], []
            else:
                ua_rows = db.execute(f'SELECT ua, COUNT(*) n FROM {access} WHERE {where} GROUP BY ua ORDER BY n DESC, ua', args).fetchall()
                cross = db.execute(f'''SELECT date(created, 'unixepoch', '+8 hours') day,
                        CASE WHEN instr(ua, 'wv)')>0 THEN 1 ELSE 0 END wv,
                        CASE WHEN (instr(lower(ua), 'iphone')>0 OR instr(lower(ua), 'ipad')>0 OR instr(lower(ua), 'ipod')>0) AND instr(ua, 'Safari/')=0 THEN 1 ELSE 0 END ios_no_safari,
                        CASE WHEN instr(lower(query), 'gclid=')>0 THEN 1 ELSE 0 END gclid,
                        CASE WHEN instr(lower(query), 'placement=')>0 THEN 1 ELSE 0 END placement,
                        COUNT(*) n
                    FROM {access} WHERE {where} GROUP BY 1,2,3,4,5 ORDER BY 1,2,3,4,5''', args).fetchall()
                events = [dict(row) for row in db.execute(f'SELECT created, body, origin FROM {clients} WHERE created>=? ORDER BY id', (since,))]
        if rename_from and domain and rename_from != domain:
            for row in events:
                row['origin'] = (row.get('origin') or '').replace(rename_from, domain)
                row['body'] = (row.get('body') or '').replace(rename_from, domain)
        scope = country or '全部'
        lines = [
            '访问日志周报',
            f'范围：最近 {days} 天，日期按香港时间',
            f'国家筛选：{scope}',
            '只含香港访客。条数按请求计，页面上的每个资源各算一条。边缘缓存命中不到源站，不会出现在这里。',
            'cf-cache-status 只记录请求头里实际带来的值；Cloudflare 默认不把这个响应头回传源站。',
            '',
            '# 1 去重后的完整 User-Agent，按条数降序',
            '条数\tUser-Agent',
        ]
        lines.extend(f'{row["n"]}\t{row["ua"]}' for row in ua_rows)
        lines.extend([
            '',
            '# 2 按日 × 含 wv) × iOS且不含 Safari/ × 带 gclid × 带 placement',
            '日期\t含wv)\tiOS且不含Safari/\t带gclid\t带placement\t请求数',
        ])
        lines.extend(f'{row["day"]}\t{row["wv"]}\t{row["ios_no_safari"]}\t{row["gclid"]}\t{row["placement"]}\t{row["n"]}' for row in cross)
        lines.append('')
        lines.extend(jump_event_lines(events, domain))
        return '\n'.join(lines) + '\n'

    def recent_access(self, since, limit, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'access_log', only_kept)
            if relation is None:
                return 0, []
            total = db.execute(f'SELECT COUNT(*) FROM {relation} WHERE created>=?', (since,)).fetchone()[0]
            rows = db.execute(f'''SELECT created,ua,ch_ua,ch_platform,ch_platform_version,ch_mobile,referer,query,wa_number,cf_cache_status,country,city,status,duration_ms,path
                FROM {relation} WHERE created>=? ORDER BY created DESC, id DESC LIMIT ?''', (since, limit)).fetchall()
        return total, [dict(row) for row in rows]

    def campaign_access(self, since, until, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'access_log', only_kept)
            if relation is None:
                return []
            rows = db.execute(f'SELECT created, ua, query, path, ip, referer, wa_number FROM {relation} WHERE created>=? AND created<?', (since, until)).fetchall()
        return [dict(row) for row in rows]

    def record_intake(self, ip, ua, origin, referer, content_type, body_length, body, status, reason):
        """One raw /wa-events request, including rejects and bodies that did not parse."""
        text = body if isinstance(body, str) else ''
        with self.connect() as db:
            db.execute('''INSERT INTO intake_log(created,ip,ua,origin,referer,content_type,body_length,body,status,reason)
                VALUES(?,?,?,?,?,?,?,?,?,?)''', (
                time.time(), (ip or '')[:80], (ua or '')[:4096], (origin or '')[:500], (referer or '')[:2048],
                (content_type or '')[:200], int(body_length), text[:8192], int(status), (reason or '')[:80]))
            latest = db.execute('SELECT MAX(id) FROM intake_log').fetchone()[0]
            if latest and latest % 200 == 0:
                db.execute('DELETE FROM intake_log WHERE created<?', (time.time() - 90 * 86400,))

    def intake_between(self, since, until, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'intake_log', only_kept)
            if relation is None:
                return []
            rows = db.execute(f'''SELECT id, created, ip, ua, origin, referer, content_type, body_length, body, status, reason
                FROM {relation} WHERE created>=? AND created<? ORDER BY created, id''', (since, until)).fetchall()
        return [dict(row) for row in rows]

    def campaign_events(self, since, until, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'client_events', only_kept)
            if relation is None:
                return []
            rows = db.execute(f'SELECT id, created, body, origin FROM {relation} WHERE created>=? AND created<? ORDER BY created, id', (since, until)).fetchall()
        return [dict(row) for row in rows]

    def recent_client_events(self, since, limit, only_kept=False):
        with self.connect() as db:
            relation = self._reading(db, 'client_events', only_kept)
            if relation is None:
                return 0, []
            total = db.execute(f'SELECT COUNT(*) FROM {relation} WHERE created>=?', (since,)).fetchone()[0]
            rows = db.execute(f'SELECT created, body, origin FROM {relation} WHERE created>=? ORDER BY created DESC, id DESC LIMIT ?', (since, limit)).fetchall()
        return total, [dict(row) for row in rows]
