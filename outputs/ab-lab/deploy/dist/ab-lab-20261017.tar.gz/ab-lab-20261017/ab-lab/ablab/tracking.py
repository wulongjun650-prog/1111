"""Save Google snippets and write them into a published page."""
import re
from pathlib import Path


GA4_SRC = re.compile(r'googletagmanager\.com/gtag/js\?id=(G-[A-Z0-9]{4,24})', re.I)
GA4_CONFIG = re.compile(r'''gtag\(\s*['"]config['"]\s*,\s*['"](G-[A-Z0-9]{4,24})['"]''', re.I)
AW_CONFIG = re.compile(r'''gtag\(\s*['"]config['"]\s*,\s*['"](AW-\d{5,15})['"]''', re.I)
GA4_LOADER = re.compile(
    r'<script\b[^>]*\bsrc\s*=\s*[\'"]https://www\.googletagmanager\.com/gtag/js\?id=G-[A-Z0-9]{4,24}[\'"][^>]*>\s*</script>',
    re.I,
)
SEND_TO = re.compile(r'''['"]send_to['"]\s*:\s*['"](AW-\d{5,15}/[A-Za-z0-9_-]{4,80})['"]''')
GOOGLE_SEND_TO = re.compile(r'''(?:^|[{,\s])(?:googleSendTo|['"]googleSendTo['"])\s*:\s*['"](AW-\d{5,15}/[A-Za-z0-9_-]{4,80})['"]''', re.M)
TEXT_SUFFIXES = {'.html', '.htm', '.js', '.mjs'}


def normalize_ga4(body):
    text = _snippet(body)
    sources = [item.upper() for item in GA4_SRC.findall(text)]
    configs = [item.upper() for item in GA4_CONFIG.findall(text)]
    if not sources or not configs:
        raise ValueError('GA4 代码需要包含 gtag.js 和 gtag config')
    if len(set(sources + configs)) != 1:
        raise ValueError('GA4 编号不一致，请只保留一个 G- 编号')
    return sources[0], text


def normalize_conversion(body):
    text = _snippet(body)
    if not re.search(r'function\s+gtag_report_conversion\s*\(', text):
        raise ValueError('转化代码需要包含 gtag_report_conversion')
    targets = SEND_TO.findall(text)
    if len(set(targets)) != 1:
        raise ValueError('转化代码需要一个 send_to 目标')
    return targets[0], text


def read_pages(pairs):
    ga4 = conversion = ''
    ga4_body = conversion_body = ''
    for name, payload in _ordered(pairs):
        text = _text(name, payload)
        if text is None:
            continue
        if not ga4:
            found = GA4_CONFIG.findall(text) or GA4_SRC.findall(text)
            if found:
                ga4 = found[0].upper()
                ga4_body = _usable(_extract_first(text, _ga4_spans(text))) or _canonical_ga4(ga4)
        if not conversion:
            literal = SEND_TO.findall(text)
            configured = GOOGLE_SEND_TO.findall(text)
            found = literal or configured
            if found:
                conversion = found[0]
                extracted = _usable(_extract_first(text, _conversion_spans(text)))
                if extracted:
                    conversion_body = extracted
                elif configured and not literal:
                    conversion_body = _google_send_to_body(text)
                else:
                    conversion_body = _canonical_conversion(conversion)
        if ga4 and conversion:
            break
    return {'ga4': ga4, 'conversion': conversion, 'ga4_body': ga4_body, 'conversion_body': conversion_body}


def rewrite_pages(pairs, ga4_body=None, conversion_body=None):
    ga4_id = normalize_ga4(ga4_body)[0] if ga4_body else ''
    send_to = normalize_conversion(conversion_body)[0] if conversion_body else ''
    decoded = []
    had_ga4 = had_conversion = False
    for name, payload in pairs:
        text = _text(name, payload)
        if text is None:
            decoded.append((name, payload, None, False))
            continue
        bom = payload.startswith(b'\xef\xbb\xbf')
        had_ga4 = had_ga4 or bool(GA4_SRC.search(text) or GA4_CONFIG.search(text))
        had_conversion = had_conversion or bool(re.search(r'function\s+gtag_report_conversion\s*\(', text) or SEND_TO.search(text) or GOOGLE_SEND_TO.search(text))
        decoded.append((name, payload, text, bom))
    edited = []
    changed = False
    for name, payload, text, bom in decoded:
        if text is None:
            edited.append((name, payload))
            continue
        updated = text
        if ga4_body:
            updated, did = _replace_ga4(updated, ga4_body.strip())
            changed = changed or did
        if conversion_body:
            updated, did = _replace_conversion(updated, conversion_body.strip())
            changed = changed or did
        edited.append((name, updated, bom, payload))
    if ga4_body and not had_ga4:
        edited, did = _insert(edited, 'index.html', ga4_body.strip())
        changed = changed or did
    if conversion_body and not had_conversion:
        edited, did = _insert(edited, 'index.html', conversion_body.strip())
        changed = changed or did
    result = []
    for item in edited:
        if len(item) == 2:
            result.append(item)
            continue
        name, updated, bom, payload = item
        if ga4_body and had_ga4:
            updated = _swap_ga4(updated, ga4_id)
        if conversion_body and had_conversion:
            updated = _swap_send_to(updated, send_to)
        updated = _ensure_aw_config(updated)
        data = updated.encode('utf-8')
        if bom:
            data = b'\xef\xbb\xbf' + data
        if data != payload:
            changed = True
        result.append((name, data))
    return result, changed


def _snippet(body):
    if not isinstance(body, str):
        raise ValueError('请粘贴完整代码')
    text = body.strip()
    if not text or len(text) > 12000 or '\x00' in text:
        raise ValueError('代码为空、过长或含无效字符')
    return text


def _text(name, payload):
    if Path(name).suffix.lower() not in TEXT_SUFFIXES:
        return None
    try:
        return payload.decode('utf-8-sig')
    except UnicodeDecodeError:
        return None


def _ordered(pairs):
    return sorted(pairs, key=lambda item: (item[0] != 'index.html', item[0]))


def _replace_ga4(text, snippet):
    spans = _ga4_spans(text)
    kept = []
    seen = set()
    for start, end in spans:
        for account in _aw_accounts(text[start:end]):
            if account not in seen:
                seen.add(account)
                kept.append(account)
    return _splice(text, spans, _with_aw_configs(snippet, kept))


def _replace_conversion(text, snippet):
    return _splice(text, _conversion_spans(text), snippet)


def _ga4_spans(text):
    spans = []
    for match in GA4_LOADER.finditer(text):
        start, end = match.start(), match.end()
        comment = _comment_before(text, start, 'google tag')
        if comment is not None:
            start = comment
        rest = text[end:]
        gap = re.match(r'(?:\s|<!--[\s\S]*?-->)*', rest).end()
        following = re.match(r'(<script\b[^>]*>)([\s\S]*?)</script>', rest[gap:], re.I)
        if following and re.search(r'''gtag\(\s*['"]config['"]''', following.group(2), re.I) and 'gtag_report_conversion' not in following.group(2):
            end += gap + following.end()
        spans.append((start, _one_newline(text, end)))
    return spans


def _conversion_spans(text):
    spans = []
    for match in re.finditer(r'function\s+gtag_report_conversion\s*\(', text):
        end = _closing_brace(text, match.end())
        if end is None:
            continue
        start = match.start()
        script_open = text.rfind('<script', 0, start)
        script_close = text.find('</script>', end)
        if script_open != -1 and script_close != -1:
            between = text[script_open:start]
            if between.count('<script') == 1 and '</script>' not in between:
                start = script_open
                end = script_close + len('</script>')
        for needle in ('conversion', 'gtag_report_conversion'):
            comment = _comment_before(text, start, needle)
            if comment is not None:
                start = comment
                break
        spans.append((start, _one_newline(text, end)))
    return spans


def _extract_first(text, spans):
    if not spans:
        return ''
    start, end = spans[0]
    return text[start:end]


def _usable(snippet):
    snippet = snippet.strip()
    if not snippet or len(snippet) > 12000 or '\x00' in snippet:
        return ''
    return snippet


def _canonical_ga4(ga4_id):
    return (
        '<!-- Google tag (gtag.js) -->\n'
        f'<script async src="https://www.googletagmanager.com/gtag/js?id={ga4_id}"></script>\n'
        '<script>\n'
        '  window.dataLayer = window.dataLayer || [];\n'
        '  function gtag(){dataLayer.push(arguments);}\n'
        "  gtag('js', new Date());\n"
        '\n'
        f"  gtag('config', '{ga4_id}');\n"
        '</script>'
    )


def _google_send_to_body(text):
    """The lines this page actually uses. Do not invent a gtag_report_conversion function."""
    parts = []
    assign = re.search(r'''^[^\n]*googleSendTo\s*:\s*['"]AW-\d{5,15}/[A-Za-z0-9_-]{4,80}['"][^\n]*''', text, re.M)
    if assign:
        parts.append(assign.group(0).strip().rstrip(','))
    call = re.search(r'''track\(\s*['"]conversion['"]\s*,\s*\{[^}\n]*CONFIG\.googleSendTo[^}\n]*\}\)''', text)
    if call:
        parts.append(call.group(0).strip())
    return _usable('\n'.join(parts))


def _canonical_conversion(send_to):
    return (
        '<!-- Event snippet for conversion page\n'
        'In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->\n'
        '<script>\n'
        'function gtag_report_conversion(url) {\n'
        '  var callback = function () {\n'
        "    if (typeof(url) != 'undefined') {\n"
        '      window.location = url;\n'
        '    }\n'
        '  };\n'
        "  gtag('event', 'conversion', {\n"
        f"      'send_to': '{send_to}',\n"
        "      'event_callback': callback\n"
        '  });\n'
        '  return false;\n'
        '}\n'
        '</script>'
    )


def _one_newline(text, end):
    if end < len(text) and text[end] == '\r':
        end += 1
    if end < len(text) and text[end] == '\n':
        end += 1
    return end


def _closing_brace(text, after_name):
    brace = text.find('{', after_name)
    if brace < 0:
        return None
    depth = 0
    for index in range(brace, len(text)):
        if text[index] == '{':
            depth += 1
        elif text[index] == '}':
            depth -= 1
            if depth == 0:
                return index + 1
    return None


def _comment_before(text, start, needle):
    prefix = text[:start].rstrip()
    if not prefix.endswith('-->'):
        return None
    opened = prefix.rfind('<!--')
    if opened < 0 or needle not in prefix[opened:].lower():
        return None
    return opened


def _splice(text, spans, snippet):
    if not spans:
        return text, False
    spans = sorted(spans)
    pieces, cursor = [], 0
    for index, (start, end) in enumerate(spans):
        if start < cursor:
            continue
        pieces.append(text[cursor:start])
        if index == 0:
            pieces.append(snippet.strip() + '\n')
        cursor = end
    pieces.append(text[cursor:])
    result = ''.join(pieces)
    return result, result != text


def _insert(items, filename, snippet):
    updated = []
    done = False
    for item in items:
        if len(item) == 2 or item[0] != filename:
            updated.append(item)
            continue
        name, text, bom, payload = item
        text = _insert_text(text, snippet)
        updated.append((name, text, bom, payload))
        done = True
    if not done:
        raise ValueError('发布页面没有 index.html，无法加入代码')
    return updated, True


def _insert_text(text, snippet):
    block = snippet.strip() + '\n'
    head = text.lower().rfind('</head>')
    if head != -1:
        return text[:head] + block + text[head:]
    body = re.search(r'<body\b[^>]*>', text, re.I)
    if body:
        return text[:body.end()] + '\n' + block + text[body.end():]
    return block + text


def _aw_accounts(chunk):
    found = []
    seen = set()
    for line in chunk.splitlines():
        if 'send_to' in line:
            continue
        for account in AW_CONFIG.findall(line):
            key = account.upper()
            if key not in seen:
                seen.add(key)
                found.append(key)
    return found


def _with_aw_configs(snippet, accounts):
    if not accounts:
        return snippet
    block = '\n'.join(f"  gtag('config', '{account}');" for account in accounts) + '\n'
    close = snippet.lower().rfind('</script>')
    if close == -1:
        return snippet.rstrip() + '\n<script>\n' + block + '</script>\n'
    return snippet[:close].rstrip() + '\n' + block + snippet[close:]


def _ensure_aw_config(text):
    """A conversion target needs its AW config. Replacing GA4 must not be the thing that drops it."""
    wanted = []
    seen = set()
    for target in SEND_TO.findall(text) + GOOGLE_SEND_TO.findall(text):
        account = target.split('/', 1)[0].upper()
        if account not in seen:
            seen.add(account)
            wanted.append(account)
    if not wanted:
        return text
    present = {item.upper() for item in AW_CONFIG.findall(text)}
    missing = [account for account in wanted if account not in present]
    if not missing:
        return text
    return _insert_aw_lines(text, missing)


def _insert_aw_lines(text, accounts):
    lines = ''.join(f"  gtag('config', '{account}');\n" for account in accounts)
    match = None
    for found in GA4_CONFIG.finditer(text):
        match = found
    if match:
        end = match.end()
        if end < len(text) and text[end] == ')':
            end += 1
        while end < len(text) and text[end] in ' \t':
            end += 1
        if end < len(text) and text[end] == ';':
            end += 1
        if end < len(text) and text[end] == '\r':
            end += 1
        if end < len(text) and text[end] == '\n':
            end += 1
        return text[:end] + lines + text[end:]
    block = '<script>\n' + lines + '</script>\n'
    head = text.lower().rfind('</head>')
    if head != -1:
        return text[:head] + block + text[head:]
    return block + text


def _swap_ga4(text, new_id):
    def source(match):
        return match.group(0) if match.group(1).upper() == new_id else match.group(0).replace(match.group(1), new_id, 1)

    def config(match):
        return match.group(0) if match.group(1).upper() == new_id else match.group(0).replace(match.group(1), new_id, 1)

    text = GA4_SRC.sub(source, text)
    return GA4_CONFIG.sub(config, text)


def _swap_send_to(text, send_to):
    def replace(match):
        return match.group(0) if match.group(1) == send_to else match.group(0).replace(match.group(1), send_to, 1)

    return GOOGLE_SEND_TO.sub(replace, SEND_TO.sub(replace, text))
